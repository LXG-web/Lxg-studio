package com.example.engine.rtmp

data class ParsedRtmpEndpoint(
    val isRtmps: Boolean,
    val host: String,
    val port: Int,
    val app: String,
    val tcUrl: String,
    val streamName: String
)

object RtmpUrlParser {
    fun parse(rawServerUrl: String, rawStreamKey: String): ParsedRtmpEndpoint {
        val trimmedUrl = rawServerUrl.trim()
        val isRtmps = trimmedUrl.startsWith("rtmps://", ignoreCase = true)
        val scheme = if (isRtmps) "rtmps://" else "rtmp://"
        val defaultPort = if (isRtmps) 443 else 1935

        var withoutScheme = if (trimmedUrl.startsWith(scheme, ignoreCase = true)) {
            trimmedUrl.substring(scheme.length)
        } else if (trimmedUrl.startsWith("rtmp://", ignoreCase = true)) {
            trimmedUrl.substring(7)
        } else if (trimmedUrl.startsWith("rtmps://", ignoreCase = true)) {
            trimmedUrl.substring(8)
        } else {
            trimmedUrl
        }

        // Clean query params if any
        val queryIndex = withoutScheme.indexOf('?')
        if (queryIndex != -1) {
            withoutScheme = withoutScheme.substring(0, queryIndex)
        }

        val firstSlash = withoutScheme.indexOf('/')
        val hostPortPart: String
        val pathPart: String

        if (firstSlash == -1) {
            hostPortPart = withoutScheme
            pathPart = "live2"
        } else {
            hostPortPart = withoutScheme.substring(0, firstSlash)
            pathPart = withoutScheme.substring(firstSlash + 1).trim('/')
        }

        var host = hostPortPart
        var port = defaultPort

        if (hostPortPart.contains(":")) {
            val parts = hostPortPart.split(":")
            host = parts[0]
            port = parts.getOrNull(1)?.toIntOrNull() ?: defaultPort
        }

        // If port was attached to path (e.g. /live2:443)
        var cleanPath = pathPart
        if (cleanPath.contains(":")) {
            val trailingPort = cleanPath.substringAfter(":").toIntOrNull()
            if (trailingPort != null) {
                port = trailingPort
                cleanPath = cleanPath.substringBefore(":")
            }
        }

        // App name: for YouTube this is "live2", for Twitch "app", for FB "rtmp"
        val app = if (cleanPath.isNotBlank()) cleanPath else "live2"

        val tcUrl = "$scheme$host:$port/$app"
        val streamName = rawStreamKey.trim().trimStart('/')

        return ParsedRtmpEndpoint(
            isRtmps = isRtmps,
            host = host,
            port = port,
            app = app,
            tcUrl = tcUrl,
            streamName = streamName
        )
    }
}
