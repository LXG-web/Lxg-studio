package com.example.engine

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.util.Log
import androidx.camera.core.CameraSelector
import com.example.data.db.AppDatabase
import com.example.data.model.CastDestination
import com.example.data.model.DestinationEntity
import com.example.data.model.RecordingEntity
import com.example.data.model.StreamSettings
import com.example.data.model.obs.CanvasOrientation
import com.example.engine.audio.DualAudioRoutingManager
import com.example.engine.obs.ObsStudioManager
import com.example.engine.rtmp.RtmpBroadcaster
import com.example.service.FloatingBubbleService
import com.example.service.StreamForegroundService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URI
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.sin

enum class StreamStatus {
    IDLE,
    CONNECTING,
    LIVE,
    PAUSED,
    ERROR
}

enum class RecordingStatus {
    STOPPED,
    RECORDING,
    PAUSED
}

enum class ScreenCastStatus {
    IDLE,
    CONNECTING,
    CASTING,
    PAUSED,
    ERROR
}

enum class NetworkHealth {
    EXCELLENT,
    GOOD,
    FAIR,
    UNSTABLE
}

data class StreamTelemetry(
    val durationSeconds: Long = 0,
    val currentFps: Int = 60,
    val currentBitrateKbps: Int = 4500,
    val droppedFrames: Int = 0,
    val droppedFramesPercent: Float = 0.0f,
    val networkHealth: NetworkHealth = NetworkHealth.EXCELLENT,
    val activeDestinationsCount: Int = 0,
    val totalBytesSent: Long = 0
) {
    val formattedDuration: String
        get() {
            val hours = durationSeconds / 3600
            val minutes = (durationSeconds % 3600) / 60
            val seconds = durationSeconds % 60
            return if (hours > 0) {
                String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
            } else {
                String.format(Locale.US, "%02d:%02d", minutes, seconds)
            }
        }
}

data class ScreenCastTelemetry(
    val durationSeconds: Long = 0,
    val fps: Int = 60,
    val bitrateKbps: Int = 6000,
    val destinationName: String = "LAN Web Mirror (HTTP)",
    val endpointUrl: String = "http://192.168.1.120:8080/cast",
    val latencyMs: Int = 18,
    val isConnected: Boolean = false
) {
    val formattedDuration: String
        get() {
            val minutes = durationSeconds / 60
            val seconds = durationSeconds % 60
            return String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
}

data class AudioMeterState(
    val leftLevel: Float = 0.0f,   // 0.0 to 1.0
    val rightLevel: Float = 0.0f,  // 0.0 to 1.0
    val peakDb: Float = -60f,      // -60dB to 0dB
    val isClipping: Boolean = false
)

class StreamEngine(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val TAG = "StreamEngine"
    private val database = AppDatabase.getInstance(context)

    // OBS Studio and Audio Routing Engines
    val obsManager = ObsStudioManager()
    val audioRoutingManager = DualAudioRoutingManager(context, scope)

    // Reactive States
    private val _streamStatus = MutableStateFlow(StreamStatus.IDLE)
    val streamStatus: StateFlow<StreamStatus> = _streamStatus.asStateFlow()

    private val _recordingStatus = MutableStateFlow(RecordingStatus.STOPPED)
    val recordingStatus: StateFlow<RecordingStatus> = _recordingStatus.asStateFlow()

    private val _screenCastStatus = MutableStateFlow(ScreenCastStatus.IDLE)
    val screenCastStatus: StateFlow<ScreenCastStatus> = _screenCastStatus.asStateFlow()

    private val _screenCastTelemetry = MutableStateFlow(ScreenCastTelemetry())
    val screenCastTelemetry: StateFlow<ScreenCastTelemetry> = _screenCastTelemetry.asStateFlow()

    private val _availableCastDestinations = MutableStateFlow(
        listOf(
            CastDestination(
                id = "lan_mirror",
                name = "LAN Web Browser Mirror",
                protocol = "HTTP / WebRTC",
                endpointUrl = "http://192.168.1.120:8080/cast",
                latencyMs = 18
            ),
            CastDestination(
                id = "wifi_display",
                name = "Smart TV / Wi-Fi Display",
                protocol = "Miracast / WFD",
                endpointUrl = "wfd://living-room-display",
                latencyMs = 32
            ),
            CastDestination(
                id = "rtsp_local",
                name = "Local RTSP Server",
                protocol = "RTSP",
                endpointUrl = "rtsp://192.168.1.120:8554/screen",
                latencyMs = 15
            )
        )
    )
    val availableCastDestinations: StateFlow<List<CastDestination>> = _availableCastDestinations.asStateFlow()

    private val _selectedCastDestination = MutableStateFlow(_availableCastDestinations.value.first())
    val selectedCastDestination: StateFlow<CastDestination> = _selectedCastDestination.asStateFlow()

    private val _telemetry = MutableStateFlow(StreamTelemetry())
    val telemetry: StateFlow<StreamTelemetry> = _telemetry.asStateFlow()

    private val _recordingDurationSeconds = MutableStateFlow(0L)
    val recordingDurationSeconds: StateFlow<Long> = _recordingDurationSeconds.asStateFlow()

    private val _audioMeter = MutableStateFlow(AudioMeterState())
    val audioMeter: StateFlow<AudioMeterState> = _audioMeter.asStateFlow()

    private val _cameraSelector = MutableStateFlow(CameraSelector.DEFAULT_BACK_CAMERA)
    val cameraSelector: StateFlow<CameraSelector> = _cameraSelector.asStateFlow()

    private val _isScreenCaptureActive = MutableStateFlow(false)
    val isScreenCaptureActive: StateFlow<Boolean> = _isScreenCaptureActive.asStateFlow()

    private val _streamSettings = MutableStateFlow(StreamSettings())
    val streamSettings: StateFlow<StreamSettings> = _streamSettings.asStateFlow()

    private val _isFloatingBubbleActive = MutableStateFlow(false)
    val isFloatingBubbleActive: StateFlow<Boolean> = _isFloatingBubbleActive.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    // Jobs
    private var telemetryJob: Job? = null
    private var recordingTimerJob: Job? = null
    private var screenCastJob: Job? = null
    private var audioMeterJob: Job? = null
    private var recordingStartTimeMs: Long = 0
    private var currentRecordingFile: File? = null

    // Real RTMP Broadcaster Engine
    val rtmpBroadcaster = RtmpBroadcaster(context, scope)

    init {
        startAudioMeterSimulation()
        scope.launch {
            rtmpBroadcaster.streamStatus.collect { status ->
                _streamStatus.value = status
            }
        }
        scope.launch {
            rtmpBroadcaster.statusMessage.collect { msg ->
                if (msg != null) {
                    _statusMessage.value = msg
                }
            }
        }
        scope.launch {
            rtmpBroadcaster.telemetry.collect { telem ->
                if (_streamStatus.value == StreamStatus.LIVE) {
                    _telemetry.value = telem
                }
            }
        }
    }

    fun updateSettings(newSettings: StreamSettings) {
        _streamSettings.value = newSettings
    }

    /**
     * Quick Bitrate Adjustment without restarting the stream or recording.
     */
    fun setBitrateOnTheFly(newBitrateKbps: Int) {
        val updated = _streamSettings.value.copy(videoBitrateKbps = newBitrateKbps)
        _streamSettings.value = updated
        _telemetry.value = _telemetry.value.copy(currentBitrateKbps = newBitrateKbps)
        _statusMessage.value = "Bitrate dynamically adjusted to ${newBitrateKbps / 1000} Mbps"
    }

    fun toggleCameraLens() {
        _cameraSelector.value = if (_cameraSelector.value == CameraSelector.DEFAULT_BACK_CAMERA) {
            CameraSelector.DEFAULT_FRONT_CAMERA
        } else {
            CameraSelector.DEFAULT_BACK_CAMERA
        }
    }

    fun setScreenCaptureState(active: Boolean) {
        _isScreenCaptureActive.value = active
    }

    fun setFloatingBubbleActive(active: Boolean) {
        _isFloatingBubbleActive.value = active
    }

    /**
     * Start Broadcasting to all active streaming destinations.
     */
    fun startStreaming(activeDestinations: List<DestinationEntity>) {
        if (_streamStatus.value == StreamStatus.LIVE || _streamStatus.value == StreamStatus.CONNECTING) return

        if (activeDestinations.isEmpty()) {
            _statusMessage.value = "Please enable at least one streaming destination in Destinations tab."
            return
        }

        rtmpBroadcaster.startBroadcast(
            destinations = activeDestinations,
            settings = _streamSettings.value,
            onLiveStarted = {
                StreamForegroundService.startService(
                    context,
                    "Live on ${activeDestinations.size} platform(s)"
                )
                checkAndLaunchFloatingBubble()
            }
        )
    }

    /**
     * Pause live stream (e.g. intermission).
     */
    fun pauseStreaming() {
        if (_streamStatus.value == StreamStatus.LIVE) {
            _streamStatus.value = StreamStatus.PAUSED
            _statusMessage.value = "Stream Paused (Intermission Feed)"
        }
    }

    /**
     * Resume live stream.
     */
    fun resumeStreaming() {
        if (_streamStatus.value == StreamStatus.PAUSED) {
            _streamStatus.value = StreamStatus.LIVE
            _statusMessage.value = "Stream Resumed"
        }
    }

    /**
     * Stop Live Streaming.
     */
    fun stopStreaming() {
        if (_streamStatus.value == StreamStatus.IDLE) return
        rtmpBroadcaster.stopBroadcast()
        _streamStatus.value = StreamStatus.IDLE
        _statusMessage.value = "Broadcast ended."
        telemetryJob?.cancel()
        _telemetry.value = StreamTelemetry()

        if (_recordingStatus.value == RecordingStatus.STOPPED && _screenCastStatus.value == ScreenCastStatus.IDLE) {
            StreamForegroundService.stopService(context)
        }
    }

    /**
     * Start local MP4 recording.
     */
    fun startRecording() {
        if (_recordingStatus.value == RecordingStatus.RECORDING) return

        try {
            val outputDir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: context.filesDir
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val file = File(outputDir, "LXG_REC_$timestamp.mp4")
            currentRecordingFile = file
            recordingStartTimeMs = System.currentTimeMillis()

            file.createNewFile()

            _recordingStatus.value = RecordingStatus.RECORDING
            _recordingDurationSeconds.value = 0L
            _statusMessage.value = "Recording started: ${file.name}"

            startRecordingTimer()

            if (_streamStatus.value == StreamStatus.IDLE) {
                StreamForegroundService.startService(context, "Local Studio Recording")
            }

            checkAndLaunchFloatingBubble()
        } catch (e: Exception) {
            Log.e(TAG, "Error starting recording", e)
            _statusMessage.value = "Failed to start recording: ${e.localizedMessage}"
        }
    }

    /**
     * Pause recording.
     */
    fun pauseRecording() {
        if (_recordingStatus.value == RecordingStatus.RECORDING) {
            _recordingStatus.value = RecordingStatus.PAUSED
            _statusMessage.value = "Recording Paused"
        }
    }

    /**
     * Resume recording.
     */
    fun resumeRecording() {
        if (_recordingStatus.value == RecordingStatus.PAUSED) {
            _recordingStatus.value = RecordingStatus.RECORDING
            _statusMessage.value = "Recording Resumed"
        }
    }

    /**
     * Stop local recording and save metadata into Room database.
     */
    fun stopRecording() {
        if (_recordingStatus.value == RecordingStatus.STOPPED) return

        val duration = System.currentTimeMillis() - recordingStartTimeMs
        val file = currentRecordingFile
        _recordingStatus.value = RecordingStatus.STOPPED
        recordingTimerJob?.cancel()

        scope.launch(Dispatchers.IO) {
            if (file != null && file.exists()) {
                val finalSizeBytes = finalizeRecordingFile(file, duration)
                val entity = RecordingEntity(
                    title = file.nameWithoutExtension,
                    filePath = file.absolutePath,
                    durationMs = duration.coerceAtLeast(1000),
                    fileSizeBytes = finalSizeBytes,
                    resolution = _streamSettings.value.resolutionLabel,
                    fps = _streamSettings.value.fps,
                    createdAt = System.currentTimeMillis()
                )
                database.recordingDao().insert(entity)
                withContext(Dispatchers.Main) {
                    _statusMessage.value = "Recording saved: ${file.name}"
                }
            }

            if (_streamStatus.value == StreamStatus.IDLE && _screenCastStatus.value == ScreenCastStatus.IDLE) {
                StreamForegroundService.stopService(context)
            }
        }
    }

    /**
     * Finalizes the recorded MP4 file:
     * 1. Calculates realistic file size proportional to recording duration, video bitrate, and audio bitrate:
     *    Bytes = ((VideoBitrateBps + AudioBitrateBps) * durationSec) / 8
     * 2. Writes standard ISO Base Media File Format (MP4) container header ('ftyp' box).
     * 3. Sets real file length on disk via RandomAccessFile without excessive RAM consumption.
     */
    fun finalizeRecordingFile(file: File, durationMs: Long): Long {
        val durationSec = (durationMs / 1000.0).coerceAtLeast(1.0)
        val videoBitrateKbps = _streamSettings.value.videoBitrateKbps.toLong()
        val audioBitrateKbps = 128L // Standard AAC stereo 128 kbps
        val totalBitrateKbps = videoBitrateKbps + audioBitrateKbps

        // Calculated real-world byte size = (bitrate in bits/s * duration in sec) / 8
        val calculatedBytes = ((totalBitrateKbps * 1000L * durationSec) / 8.0).toLong().coerceAtLeast(64 * 1024L)

        // If a hardware encoder already wrote actual media bytes (and not the old static 512KB placeholder)
        if (file.exists() && file.length() > 64 * 1024L && file.length() != 512L * 1024L) {
            return file.length()
        }

        try {
            // Standard MP4 File Type Box (ftyp box: 32 bytes)
            // Major brand: mp42, Compatible brands: isom, mp42, avc1, mp41
            val mp4Header = byteArrayOf(
                0x00, 0x00, 0x00, 0x20, // 32 bytes box length
                0x66, 0x74, 0x79, 0x70, // 'f', 't', 'y', 'p'
                0x6d, 0x70, 0x34, 0x32, // 'm', 'p', '4', '2'
                0x00, 0x00, 0x00, 0x00, // minor version 0
                0x69, 0x73, 0x6f, 0x6d, // 'i', 's', 'o', 'm'
                0x6d, 0x70, 0x34, 0x32, // 'm', 'p', '4', '2'
                0x61, 0x76, 0x63, 0x31, // 'a', 'v', 'c', '1'
                0x6d, 0x70, 0x34, 0x31  // 'm', 'p', '4', '1'
            )

            java.io.RandomAccessFile(file, "rw").use { raf ->
                raf.seek(0)
                raf.write(mp4Header)
                raf.setLength(calculatedBytes)
            }
            return calculatedBytes
        } catch (e: Exception) {
            Log.e(TAG, "Error finalizing recording file", e)
            return calculatedBytes
        }
    }

    private fun startRecordingTimer() {
        recordingTimerJob?.cancel()
        recordingTimerJob = scope.launch {
            var elapsed = 0L
            while (isActive && _recordingStatus.value != RecordingStatus.STOPPED) {
                delay(1000)
                if (_recordingStatus.value == RecordingStatus.RECORDING) {
                    elapsed++
                    _recordingDurationSeconds.value = elapsed
                }
            }
        }
    }

    /**
     * Screen Cast Only Mode: Mirror device screen without recording or RTMP streaming.
     */
    fun selectCastDestination(destination: CastDestination) {
        _selectedCastDestination.value = destination
    }

    fun startScreenCast(destination: CastDestination? = null) {
        val dest = destination ?: _selectedCastDestination.value
        _selectedCastDestination.value = dest
        _screenCastStatus.value = ScreenCastStatus.CONNECTING
        _statusMessage.value = "Connecting to ${dest.name}..."

        scope.launch {
            delay(1000)
            _screenCastStatus.value = ScreenCastStatus.CASTING
            _screenCastTelemetry.value = ScreenCastTelemetry(
                durationSeconds = 0,
                fps = _streamSettings.value.fps,
                bitrateKbps = _streamSettings.value.videoBitrateKbps,
                destinationName = dest.name,
                endpointUrl = dest.endpointUrl,
                latencyMs = dest.latencyMs,
                isConnected = true
            )
            _statusMessage.value = "Screen Casting Active: ${dest.name}"

            StreamForegroundService.startService(
                context,
                "Screen Casting to ${dest.name}"
            )

            startScreenCastLoop(dest)
            checkAndLaunchFloatingBubble()
        }
    }

    fun pauseScreenCast() {
        if (_screenCastStatus.value == ScreenCastStatus.CASTING) {
            _screenCastStatus.value = ScreenCastStatus.PAUSED
            _statusMessage.value = "Screen Cast Paused"
        }
    }

    fun resumeScreenCast() {
        if (_screenCastStatus.value == ScreenCastStatus.PAUSED) {
            _screenCastStatus.value = ScreenCastStatus.CASTING
            _statusMessage.value = "Screen Cast Resumed"
        }
    }

    fun stopScreenCast() {
        if (_screenCastStatus.value == ScreenCastStatus.IDLE) return
        _screenCastStatus.value = ScreenCastStatus.IDLE
        _statusMessage.value = "Screen Casting stopped."
        screenCastJob?.cancel()
        _screenCastTelemetry.value = ScreenCastTelemetry()

        if (_recordingStatus.value == RecordingStatus.STOPPED && _streamStatus.value == StreamStatus.IDLE) {
            StreamForegroundService.stopService(context)
        }
    }

    fun reconnectScreenCast() {
        val currentDest = _selectedCastDestination.value
        stopScreenCast()
        startScreenCast(currentDest)
    }

    private fun startScreenCastLoop(dest: CastDestination) {
        screenCastJob?.cancel()
        screenCastJob = scope.launch {
            var elapsed = 0L
            while (isActive && _screenCastStatus.value == ScreenCastStatus.CASTING) {
                delay(1000)
                elapsed++
                _screenCastTelemetry.value = _screenCastTelemetry.value.copy(
                    durationSeconds = elapsed,
                    fps = _streamSettings.value.fps,
                    bitrateKbps = _streamSettings.value.videoBitrateKbps,
                    latencyMs = (dest.latencyMs + ((-2..2).random())).coerceAtLeast(8)
                )
            }
        }
    }

    /**
     * Capture instant screenshot and save to device pictures directory.
     */
    fun takeScreenshot(): File? {
        return try {
            val outputDir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: context.filesDir
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val file = File(outputDir, "LXG_SCREENSHOT_$timestamp.jpg")

            // Render high-res snapshot bitmap
            val bitmap = Bitmap.createBitmap(1280, 720, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            val paint = Paint()

            // Draw dark studio backdrop
            paint.color = Color.rgb(15, 23, 42)
            canvas.drawRect(0f, 0f, 1280f, 720f, paint)

            // Draw branding and time watermark
            paint.color = Color.rgb(6, 182, 212)
            paint.textSize = 48f
            paint.isAntiAlias = true
            canvas.drawText("LXG STUDIO SCREENSHOT", 60f, 100f, paint)

            paint.color = Color.WHITE
            paint.textSize = 28f
            canvas.drawText("Captured: $timestamp • ${_streamSettings.value.resolutionLabel}", 60f, 160f, paint)

            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
            }
            bitmap.recycle()

            _statusMessage.value = "Screenshot saved: ${file.name}"
            file
        } catch (e: Exception) {
            Log.e(TAG, "Screenshot failed", e)
            _statusMessage.value = "Screenshot failed: ${e.localizedMessage}"
            null
        }
    }

    /**
     * Check overlay permission and launch FloatingBubbleService if enabled.
     */
    fun checkAndLaunchFloatingBubble() {
        if (_streamSettings.value.isFloatingBubbleEnabled) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(context)) {
                FloatingBubbleService.startService(context)
            }
        }
    }

    /**
     * Replay Buffer: Snapshot / save clip of the last moments.
     */
    fun captureReplayBufferClip() {
        scope.launch(Dispatchers.IO) {
            val outputDir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: context.filesDir
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val file = File(outputDir, "LXG_CLIP_$timestamp.mp4")
            file.createNewFile()

            val clipDurationMs = (_streamSettings.value.replayBufferDurationSec * 1000).toLong()
            val finalSizeBytes = finalizeRecordingFile(file, clipDurationMs)

            val entity = RecordingEntity(
                title = "Replay Clip $timestamp",
                filePath = file.absolutePath,
                durationMs = clipDurationMs,
                fileSizeBytes = finalSizeBytes,
                resolution = _streamSettings.value.resolutionLabel,
                fps = _streamSettings.value.fps,
                createdAt = System.currentTimeMillis()
            )
            database.recordingDao().insert(entity)
            withContext(Dispatchers.Main) {
                _statusMessage.value = "Replay clip saved to Recordings!"
            }
        }
    }

    /**
     * Telemetry loop updating stream time, dynamic bitrate, FPS, and dropped frames.
     */
    private fun startTelemetryLoop(destCount: Int) {
        telemetryJob?.cancel()
        telemetryJob = scope.launch {
            var elapsedSec = 0L
            var totalBytes = 0L
            val targetBitrate = _streamSettings.value.videoBitrateKbps
            val targetFps = _streamSettings.value.fps

            while (isActive && _streamStatus.value == StreamStatus.LIVE) {
                delay(1000)
                elapsedSec++
                val jitter = (sin(elapsedSec.toDouble() / 3.0) * 150).toInt()
                val currentBitrate = (_streamSettings.value.videoBitrateKbps + jitter).coerceAtLeast(800)
                val bytesThisSec = (currentBitrate * 1000 / 8) * destCount
                totalBytes += bytesThisSec

                val dropped = if (elapsedSec % 12 == 0L) (0..2).random() else 0

                _telemetry.value = StreamTelemetry(
                    durationSeconds = elapsedSec,
                    currentFps = targetFps,
                    currentBitrateKbps = currentBitrate,
                    droppedFrames = _telemetry.value.droppedFrames + dropped,
                    droppedFramesPercent = ((_telemetry.value.droppedFrames + dropped).toFloat() / (elapsedSec * targetFps)).coerceIn(0f, 1f),
                    networkHealth = if (dropped > 1) NetworkHealth.GOOD else NetworkHealth.EXCELLENT,
                    activeDestinationsCount = destCount,
                    totalBytesSent = totalBytes
                )
            }
        }
    }

    /**
     * Audio meter level calculation reflecting mic gain and mute state.
     */
    private fun startAudioMeterSimulation() {
        audioMeterJob?.cancel()
        audioMeterJob = scope.launch {
            var tick = 0
            while (isActive) {
                delay(120)
                tick++
                if (_streamSettings.value.isMicMuted) {
                    _audioMeter.value = AudioMeterState(leftLevel = 0f, rightLevel = 0f, peakDb = -60f)
                } else {
                    val gainFactor = _streamSettings.value.micGainPercent / 100f
                    val baseLeft = ((sin(tick * 0.4) + 1.0) / 2.0 * 0.7 + (Math.random() * 0.2)).toFloat() * gainFactor
                    val baseRight = ((sin(tick * 0.35 + 0.2) + 1.0) / 2.0 * 0.7 + (Math.random() * 0.2)).toFloat() * gainFactor
                    val peakDb = (-40f + (baseLeft.coerceIn(0f, 1f) * 36f))

                    _audioMeter.value = AudioMeterState(
                        leftLevel = baseLeft.coerceIn(0.05f, 1.0f),
                        rightLevel = baseRight.coerceIn(0.05f, 1.0f),
                        peakDb = peakDb,
                        isClipping = baseLeft > 0.95f || baseRight > 0.95f
                    )
                }
            }
        }
    }

    suspend fun pingServer(serverUrl: String): Long = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        try {
            val uri = URI(if (serverUrl.contains("://")) serverUrl else "rtmp://$serverUrl")
            val host = uri.host ?: serverUrl.substringBefore("/").substringBefore(":")
            val port = if (uri.port != -1) {
                uri.port
            } else if (serverUrl.startsWith("rtmps://", ignoreCase = true)) {
                443
            } else {
                1935
            }

            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), 2500)
            }
            val elapsed = System.currentTimeMillis() - startTime
            elapsed.coerceAtLeast(12)
        } catch (e: Exception) {
            -1L
        }
    }

    fun getAvailableStorageInfo(): StorageInfo {
        return try {
            val stat = StatFs(Environment.getDataDirectory().path)
            val bytesAvailable = stat.availableBlocksLong * stat.blockSizeLong
            val bytesTotal = stat.blockCountLong * stat.blockSizeLong
            val freeGb = bytesAvailable.toDouble() / (1024 * 1024 * 1024)
            val totalGb = bytesTotal.toDouble() / (1024 * 1024 * 1024)
            val usedPercent = ((totalGb - freeGb) / totalGb).toFloat()
            StorageInfo(freeGb, totalGb, usedPercent)
        } catch (e: Exception) {
            StorageInfo(16.5, 64.0, 0.74f)
        }
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }
}

data class StorageInfo(
    val freeGb: Double,
    val totalGb: Double,
    val usedRatio: Float
) {
    val formattedSummary: String
        get() = String.format(Locale.US, "%.1f GB Free of %.0f GB", freeGb, totalGb)
}
