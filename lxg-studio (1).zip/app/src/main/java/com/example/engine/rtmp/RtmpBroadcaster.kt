package com.example.engine.rtmp

import android.content.Context
import android.util.Log
import com.example.data.model.DestinationEntity
import com.example.data.model.StreamSettings
import com.example.data.security.KeyStoreEncryptionHelper
import com.example.engine.NetworkHealth
import com.example.engine.StreamStatus
import com.example.engine.StreamTelemetry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

class RtmpBroadcaster(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val TAG = "RtmpBroadcaster"

    private val activeSessions = ConcurrentHashMap<Long, RtmpSession>()
    private var telemetryJob: Job? = null
    private var broadcastJob: Job? = null

    private val _streamStatus = MutableStateFlow(StreamStatus.IDLE)
    val streamStatus: StateFlow<StreamStatus> = _streamStatus.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _telemetry = MutableStateFlow(StreamTelemetry())
    val telemetry: StateFlow<StreamTelemetry> = _telemetry.asStateFlow()

    fun startBroadcast(
        destinations: List<DestinationEntity>,
        settings: StreamSettings,
        onLiveStarted: () -> Unit
    ) {
        if (_streamStatus.value == StreamStatus.LIVE || _streamStatus.value == StreamStatus.CONNECTING) {
            return
        }

        if (destinations.isEmpty()) {
            _statusMessage.value = "No destinations enabled. Please enable YouTube Live or custom RTMP in Destinations tab."
            _streamStatus.value = StreamStatus.IDLE
            return
        }

        stopBroadcast()

        _streamStatus.value = StreamStatus.CONNECTING
        _statusMessage.value = "Connecting to ${destinations.size} broadcast endpoint(s)..."

        broadcastJob = scope.launch(Dispatchers.IO) {
            var anyConnected = false
            val errors = mutableListOf<String>()

            for (dest in destinations) {
                val plainKey = try {
                    if (dest.encryptedKey.isNotBlank()) {
                        KeyStoreEncryptionHelper.decrypt(dest.encryptedKey, dest.iv)
                    } else ""
                } catch (e: Exception) {
                    Log.e(TAG, "Decryption error for ${dest.label}", e)
                    ""
                }

                if (plainKey.isBlank()) {
                    val msg = "${dest.label}: Stream Key is empty! Please paste your YouTube Stream Key in the Destinations tab."
                    errors.add(msg)
                    continue
                }

                val session = RtmpSession(
                    serverUrl = dest.serverUrl,
                    streamKey = plainKey,
                    settings = settings,
                    onStatusUpdate = { status ->
                        scope.launch(Dispatchers.Main) {
                            _statusMessage.value = "[${dest.platformName}] $status"
                        }
                    },
                    onError = { errMsg ->
                        scope.launch(Dispatchers.Main) {
                            Log.e(TAG, "Destination ${dest.label} error: $errMsg")
                            _statusMessage.value = "[${dest.platformName}] Error: $errMsg"
                            _streamStatus.value = StreamStatus.ERROR
                        }
                    },
                    onConnected = {
                        scope.launch(Dispatchers.Main) {
                            anyConnected = true
                            _streamStatus.value = StreamStatus.LIVE
                            _statusMessage.value = "LIVE on ${dest.label}! Transmitting feed to YouTube Live..."
                            onLiveStarted()
                        }
                    }
                )

                activeSessions[dest.id] = session

                // Start session on separate thread
                launch(Dispatchers.IO) {
                    session.start()
                }
            }

            if (errors.isNotEmpty() && activeSessions.isEmpty()) {
                withContext(Dispatchers.Main) {
                    _statusMessage.value = errors.first()
                    _streamStatus.value = StreamStatus.ERROR
                }
                return@launch
            }

            // Start telemetry polling
            startTelemetryMonitor(settings)
        }
    }

    private fun startTelemetryMonitor(settings: StreamSettings) {
        telemetryJob?.cancel()
        telemetryJob = scope.launch {
            var elapsedSec = 0L
            val targetFps = settings.fps
            val configuredBitrate = settings.videoBitrateKbps

            while (isActive && (_streamStatus.value == StreamStatus.LIVE || _streamStatus.value == StreamStatus.CONNECTING)) {
                delay(1000)
                if (_streamStatus.value == StreamStatus.LIVE) {
                    elapsedSec++
                    var totalBytes = 0L
                    var totalBitrate = 0
                    var totalDropped = 0

                    for (session in activeSessions.values) {
                        totalBytes += session.totalBytesSent
                        totalBitrate += session.currentBitrateKbps
                        totalDropped += session.droppedFrames
                    }

                    val effectiveBitrate = if (totalBitrate > 0) totalBitrate else configuredBitrate
                    val health = if (totalDropped > 5) NetworkHealth.UNSTABLE
                    else if (totalDropped > 1) NetworkHealth.GOOD
                    else NetworkHealth.EXCELLENT

                    _telemetry.value = StreamTelemetry(
                        durationSeconds = elapsedSec,
                        currentFps = targetFps,
                        currentBitrateKbps = effectiveBitrate,
                        droppedFrames = totalDropped,
                        droppedFramesPercent = (totalDropped.toFloat() / (elapsedSec * targetFps).coerceAtLeast(1L)).coerceIn(0f, 1f),
                        networkHealth = health,
                        activeDestinationsCount = activeSessions.size,
                        totalBytesSent = totalBytes
                    )
                }
            }
        }
    }

    fun stopBroadcast() {
        telemetryJob?.cancel()
        broadcastJob?.cancel()
        telemetryJob = null
        broadcastJob = null

        for ((_, session) in activeSessions) {
            session.close()
        }
        activeSessions.clear()

        _streamStatus.value = StreamStatus.IDLE
        _telemetry.value = StreamTelemetry()
        _statusMessage.value = "Broadcast ended."
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }
}
