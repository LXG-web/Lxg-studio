package com.example.ui

import android.app.Application
import android.media.MediaCodecList
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.LXGApplication
import com.example.data.model.DestinationEntity
import com.example.data.model.HardwareEncoderInfo
import com.example.data.model.RecordingEntity
import com.example.data.model.SceneEntity
import com.example.data.model.StreamSettings
import com.example.data.model.obs.CanvasBackgroundType
import com.example.data.model.obs.CanvasConfig
import com.example.data.model.obs.CanvasOrientation
import com.example.data.model.obs.CanvasPreset
import com.example.data.model.obs.CanvasScaleMode
import com.example.data.model.obs.ObsScene
import com.example.data.model.obs.ObsSource
import com.example.data.model.obs.SourceType
import com.example.data.security.KeyStoreEncryptionHelper
import com.example.engine.audio.AudioChannelMeter
import com.example.engine.audio.DualAudioMixerState
import com.example.engine.AudioMeterState
import com.example.engine.RecordingStatus
import com.example.engine.ScreenCastStatus
import com.example.engine.ScreenCastTelemetry
import com.example.engine.StorageInfo
import com.example.engine.StreamEngine
import com.example.engine.StreamStatus
import com.example.engine.StreamTelemetry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

enum class NavigationTab(val label: String) {
    HOME("Home"),
    STUDIO("Studio"),
    DESTINATIONS("Destinations"),
    RECORDINGS("Recordings"),
    SETTINGS("Settings")
}

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as LXGApplication
    private val database = app.database
    val streamEngine = app.streamEngine

    // Current Screen Navigation
    private val _currentTab = MutableStateFlow(NavigationTab.HOME)
    val currentTab: StateFlow<NavigationTab> = _currentTab.asStateFlow()

    // Database Flows
    val destinations: StateFlow<List<DestinationEntity>> = database.destinationDao()
        .getAllDestinations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recordings: StateFlow<List<RecordingEntity>> = database.recordingDao()
        .getAllRecordings()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val scenes: StateFlow<List<SceneEntity>> = database.sceneDao()
        .getAllScenes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Scene
    private val _selectedScene = MutableStateFlow<SceneEntity?>(null)
    val selectedScene: StateFlow<SceneEntity?> = _selectedScene.asStateFlow()

    // Engine States delegated for easy Composable consumption
    val streamStatus: StateFlow<StreamStatus> = streamEngine.streamStatus
    val recordingStatus: StateFlow<RecordingStatus> = streamEngine.recordingStatus
    val screenCastStatus: StateFlow<ScreenCastStatus> = streamEngine.screenCastStatus
    val screenCastTelemetry: StateFlow<ScreenCastTelemetry> = streamEngine.screenCastTelemetry
    val availableCastDestinations: StateFlow<List<com.example.data.model.CastDestination>> = streamEngine.availableCastDestinations
    val selectedCastDestination: StateFlow<com.example.data.model.CastDestination> = streamEngine.selectedCastDestination
    val recordingDurationSeconds: StateFlow<Long> = streamEngine.recordingDurationSeconds
    val telemetry: StateFlow<StreamTelemetry> = streamEngine.telemetry
    val audioMeter: StateFlow<AudioMeterState> = streamEngine.audioMeter
    val streamSettings: StateFlow<StreamSettings> = streamEngine.streamSettings
    val cameraSelector = streamEngine.cameraSelector
    val isScreenCaptureActive = streamEngine.isScreenCaptureActive
    val isFloatingBubbleActive = streamEngine.isFloatingBubbleActive
    val statusMessage = streamEngine.statusMessage

    // OBS Studio Engine Flows
    val obsManager = streamEngine.obsManager
    val audioRoutingManager = streamEngine.audioRoutingManager
    val obsScenes: StateFlow<List<ObsScene>> = obsManager.scenes
    val activeObsScene: StateFlow<ObsScene?> = obsManager.activeScene
    val canvasConfig: StateFlow<CanvasConfig> = obsManager.canvasConfig
    val selectedObsSource: StateFlow<ObsSource?> = obsManager.selectedSource

    // Dual Audio Routing & Mixer Flows
    val dualMixerState: StateFlow<DualAudioMixerState> = audioRoutingManager.mixerState
    val dualMicMeter: StateFlow<AudioChannelMeter> = audioRoutingManager.micMeter
    val dualInternalMeter: StateFlow<AudioChannelMeter> = audioRoutingManager.internalMeter

    // Storage info
    private val _storageInfo = MutableStateFlow(streamEngine.getAvailableStorageInfo())
    val storageInfo: StateFlow<StorageInfo> = _storageInfo.asStateFlow()

    // Hardware Encoders detected on device
    private val _hardwareEncoders = MutableStateFlow<List<HardwareEncoderInfo>>(emptyList())
    val hardwareEncoders: StateFlow<List<HardwareEncoderInfo>> = _hardwareEncoders.asStateFlow()

    // Modals & UI helpers
    private val _activePlaybackRecording = MutableStateFlow<RecordingEntity?>(null)
    val activePlaybackRecording: StateFlow<RecordingEntity?> = _activePlaybackRecording.asStateFlow()

    private val _showAddDestinationDialog = MutableStateFlow(false)
    val showAddDestinationDialog: StateFlow<Boolean> = _showAddDestinationDialog.asStateFlow()

    private val _destinationForEdit = MutableStateFlow<DestinationEntity?>(null)
    val destinationForEdit: StateFlow<DestinationEntity?> = _destinationForEdit.asStateFlow()

    init {
        detectHardwareEncoders()
        refreshStorageInfo()
    }

    fun selectTab(tab: NavigationTab) {
        _currentTab.value = tab
    }

    fun selectScene(scene: SceneEntity) {
        _selectedScene.value = scene
        streamEngine.setScreenCaptureState(scene.isScreenEnabled)
    }

    fun toggleDestination(destination: DestinationEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            database.destinationDao().updateEnabled(destination.id, !destination.isEnabled)
        }
    }

    fun testDestinationPing(destination: DestinationEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            val ping = streamEngine.pingServer(destination.serverUrl)
            database.destinationDao().updatePing(destination.id, ping)
        }
    }

    fun saveDestination(
        id: Long = 0,
        platformName: String,
        label: String,
        serverUrl: String,
        streamKey: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val existing = _destinationForEdit.value
            val entity = if (streamKey == "retained_key" && existing != null) {
                existing.copy(
                    platformName = platformName,
                    label = label.ifBlank { platformName },
                    serverUrl = serverUrl.trim()
                )
            } else {
                val encrypted = KeyStoreEncryptionHelper.encrypt(streamKey)
                val masked = KeyStoreEncryptionHelper.maskKey(streamKey)
                DestinationEntity(
                    id = id,
                    platformName = platformName,
                    label = label.ifBlank { platformName },
                    serverUrl = serverUrl.trim(),
                    encryptedKey = encrypted.cipherTextBase64,
                    iv = encrypted.ivBase64,
                    maskedKey = masked,
                    isEnabled = true
                )
            }
            if (id == 0L) {
                database.destinationDao().insert(entity)
            } else {
                database.destinationDao().update(entity)
            }
            _showAddDestinationDialog.value = false
            _destinationForEdit.value = null
        }
    }

    fun deleteDestination(destination: DestinationEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            database.destinationDao().delete(destination)
        }
    }

    fun openAddDestinationDialog(editTarget: DestinationEntity? = null) {
        _destinationForEdit.value = editTarget
        _showAddDestinationDialog.value = true
    }

    fun closeAddDestinationDialog() {
        _showAddDestinationDialog.value = false
        _destinationForEdit.value = null
    }

    fun startStreaming() {
        viewModelScope.launch(Dispatchers.IO) {
            val enabledDestinations = database.destinationDao().getEnabledDestinations()
            streamEngine.startStreaming(enabledDestinations)
        }
    }

    fun stopStreaming() {
        streamEngine.stopStreaming()
    }

    fun toggleStreaming() {
        if (streamStatus.value == StreamStatus.LIVE || streamStatus.value == StreamStatus.CONNECTING) {
            stopStreaming()
        } else {
            startStreaming()
        }
    }

    fun toggleRecording() {
        if (recordingStatus.value == RecordingStatus.RECORDING) {
            streamEngine.stopRecording()
            refreshStorageInfo()
        } else {
            streamEngine.startRecording()
        }
    }

    fun captureReplayBuffer() {
        streamEngine.captureReplayBufferClip()
        refreshStorageInfo()
    }

    fun deleteRecording(recording: RecordingEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val file = File(recording.filePath)
                if (file.exists()) {
                    file.delete()
                }
            } catch (e: Exception) {
                // ignore
            }
            database.recordingDao().delete(recording)
            refreshStorageInfo()
        }
    }

    fun openPlayback(recording: RecordingEntity) {
        _activePlaybackRecording.value = recording
    }

    fun closePlayback() {
        _activePlaybackRecording.value = null
    }

    fun updateStreamSettings(settings: StreamSettings) {
        streamEngine.updateSettings(settings)
    }

    fun toggleCameraLens() {
        streamEngine.toggleCameraLens()
    }

    fun toggleMicMute() {
        val current = streamSettings.value
        updateStreamSettings(current.copy(isMicMuted = !current.isMicMuted))
    }

    fun setMicGain(gain: Int) {
        val current = streamSettings.value
        updateStreamSettings(current.copy(micGainPercent = gain))
    }

    fun updateSceneOverlays(sceneId: Long, textOverlay: String, showWatermark: Boolean, showTimestamp: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            val scene = _selectedScene.value ?: scenes.value.firstOrNull { it.id == sceneId }
            if (scene != null) {
                val updated = scene.copy(
                    textOverlay = textOverlay,
                    showWatermark = showWatermark,
                    showTimestamp = showTimestamp
                )
                database.sceneDao().update(updated)
                _selectedScene.value = updated
            }
        }
    }

    fun refreshStorageInfo() {
        _storageInfo.value = streamEngine.getAvailableStorageInfo()
    }

    private fun detectHardwareEncoders() {
        viewModelScope.launch(Dispatchers.Default) {
            val list = mutableListOf<HardwareEncoderInfo>()
            try {
                val codecList = MediaCodecList(MediaCodecList.REGULAR_CODECS)
                for (info in codecList.codecInfos) {
                    if (!info.isEncoder) continue
                    for (type in info.supportedTypes) {
                        if (type.startsWith("video/")) {
                            val isHw = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                                info.isHardwareAccelerated
                            } else {
                                !info.name.startsWith("OMX.google.", ignoreCase = true)
                            }
                            list.add(
                                HardwareEncoderInfo(
                                    name = info.name,
                                    mimeType = type,
                                    isHardwareAccelerated = isHw
                                )
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                // fallback
            }
            _hardwareEncoders.value = list.distinctBy { "${it.name}_${it.mimeType}" }
        }
    }

    fun clearStatusMessage() {
        streamEngine.clearStatusMessage()
    }

    fun startScreenCast(destination: com.example.data.model.CastDestination? = null) {
        streamEngine.startScreenCast(destination)
    }

    fun pauseScreenCast() {
        streamEngine.pauseScreenCast()
    }

    fun resumeScreenCast() {
        streamEngine.resumeScreenCast()
    }

    fun stopScreenCast() {
        streamEngine.stopScreenCast()
    }

    fun reconnectScreenCast() {
        streamEngine.reconnectScreenCast()
    }

    fun selectCastDestination(destination: com.example.data.model.CastDestination) {
        streamEngine.selectCastDestination(destination)
    }

    fun pauseRecording() {
        streamEngine.pauseRecording()
    }

    fun resumeRecording() {
        streamEngine.resumeRecording()
    }

    fun takeScreenshot() {
        streamEngine.takeScreenshot()
        refreshStorageInfo()
    }

    fun setBitrateOnTheFly(kbps: Int) {
        streamEngine.setBitrateOnTheFly(kbps)
    }

    fun toggleFloatingBubble() {
        val current = streamSettings.value.isFloatingBubbleEnabled
        val updated = !current
        updateStreamSettings(streamSettings.value.copy(isFloatingBubbleEnabled = updated))
        if (updated) {
            streamEngine.checkAndLaunchFloatingBubble()
        } else {
            com.example.service.FloatingBubbleService.stopService(app)
        }
    }

    // OBS Studio Actions
    fun setCanvasOrientation(orientation: CanvasOrientation) {
        obsManager.setOrientation(orientation)
    }

    fun setCanvasPreset(preset: CanvasPreset) {
        obsManager.setCanvasPreset(preset)
    }

    fun setScaleMode(scaleMode: CanvasScaleMode) {
        obsManager.setScaleMode(scaleMode)
    }

    fun setBackgroundType(bgType: CanvasBackgroundType) {
        obsManager.setBackgroundType(bgType)
    }

    fun toggleSafeZones() {
        obsManager.toggleSafeZones()
    }

    fun selectObsScene(sceneId: String) {
        obsManager.selectScene(sceneId)
    }

    fun createCustomObsScene(name: String) {
        obsManager.createCustomScene(name)
    }

    fun duplicateObsScene() {
        obsManager.duplicateActiveScene()
    }

    fun deleteObsScene(sceneId: String) {
        obsManager.deleteScene(sceneId)
    }

    fun renameObsScene(sceneId: String, newName: String) {
        obsManager.renameScene(sceneId, newName)
    }

    fun selectObsSource(source: ObsSource?) {
        obsManager.selectSource(source)
    }

    fun toggleObsSourceVisibility(sourceId: String) {
        obsManager.toggleSourceVisibility(sourceId)
    }

    fun toggleObsSourceLock(sourceId: String) {
        obsManager.toggleSourceLock(sourceId)
    }

    fun removeObsSource(sourceId: String) {
        obsManager.removeSource(sourceId)
    }

    fun addObsSource(type: SourceType, name: String? = null) {
        obsManager.addSource(type, name)
    }

    fun bringObsSourceForward(sourceId: String) {
        obsManager.bringSourceForward(sourceId)
    }

    fun sendObsSourceBackward(sourceId: String) {
        obsManager.sendSourceBackward(sourceId)
    }

    fun updateObsSourceTransform(
        sourceId: String,
        newX: Float,
        newY: Float,
        newW: Float,
        newH: Float
    ) {
        obsManager.updateSourceTransform(sourceId, newX, newY, newW, newH)
    }

    fun updateObsSourceProperties(
        sourceId: String,
        text: String? = null,
        opacity: Float? = null,
        shapeType: String? = null
    ) {
        obsManager.updateSourceProperties(sourceId, text, opacity, shapeType)
    }

    // Dual Audio Mixer Actions
    fun setMicMixerVolume(percent: Int) {
        audioRoutingManager.setMicVolume(percent)
    }

    fun toggleMixerMicMute() {
        audioRoutingManager.toggleMicMute()
    }

    fun setInternalMixerVolume(percent: Int) {
        audioRoutingManager.setInternalVolume(percent)
    }

    fun toggleMixerInternalMute() {
        audioRoutingManager.toggleInternalMute()
    }

    fun toggleNoiseSuppression() {
        audioRoutingManager.toggleNoiseSuppression()
    }

    fun toggleAec() {
        audioRoutingManager.toggleAec()
    }

    fun setAudioDelayMs(delayMs: Int) {
        audioRoutingManager.setAudioDelayMs(delayMs)
    }

    fun toggleBluetoothSco() {
        audioRoutingManager.toggleBluetoothSco()
    }
}
