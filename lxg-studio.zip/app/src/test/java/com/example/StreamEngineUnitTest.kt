package com.example

import com.example.data.model.StreamSettings
import com.example.data.security.KeyStoreEncryptionHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class StreamEngineUnitTest {

    @Test
    fun testStreamKeyMasking() {
        val shortKey = "123"
        assertEquals("••••••••", KeyStoreEncryptionHelper.maskKey(shortKey))

        val fullKey = "live_9876543210_abcdef"
        val masked = KeyStoreEncryptionHelper.maskKey(fullKey)
        assertTrue(masked.startsWith("••••••••"))
        assertTrue(masked.endsWith("cdef"))
    }

    @Test
    fun testDefaultSettings() {
        val settings = StreamSettings()
        assertEquals(1920, settings.resolutionWidth)
        assertEquals(1080, settings.resolutionHeight)
        assertEquals(60, settings.fps)
        assertEquals(4500, settings.videoBitrateKbps)
        assertEquals("4500 kbps", settings.formattedBitrate)
    }

    @Test
    fun testRecordingSizeScalesWithDuration() {
        val shortDurationMs = 5_000L // 5 seconds
        val mediumDurationMs = 60_000L // 1 minute
        val longDurationMs = 600_000L // 10 minutes

        val testRecShort = com.example.data.model.RecordingEntity(
            title = "Short Video",
            filePath = "/dummy/short.mp4",
            durationMs = shortDurationMs,
            fileSizeBytes = 0L,
            resolution = "1080p FHD",
            fps = 60,
            createdAt = System.currentTimeMillis()
        )

        val testRecMedium = testRecShort.copy(title = "Medium Video", durationMs = mediumDurationMs)
        val testRecLong = testRecShort.copy(title = "Long Video", durationMs = longDurationMs)

        val sizeShort = com.example.ui.recordings.getEffectiveRecordingSize(testRecShort)
        val sizeMedium = com.example.ui.recordings.getEffectiveRecordingSize(testRecMedium)
        val sizeLong = com.example.ui.recordings.getEffectiveRecordingSize(testRecLong)

        // Verify that size scales with duration and is NOT stuck at 0.5 MB (524288 bytes)
        assertTrue("Short recording should be greater than 1 MB at 1080p", sizeShort > 1024 * 1024)
        assertTrue("Medium recording size must be significantly larger than short recording", sizeMedium > sizeShort * 8)
        assertTrue("10-minute recording should be over 400 MB", sizeLong > 400 * 1024 * 1024)

        // Formatted strings
        val formattedShort = com.example.ui.recordings.formatRecordingSize(sizeShort)
        val formattedMedium = com.example.ui.recordings.formatRecordingSize(sizeMedium)
        val formattedLong = com.example.ui.recordings.formatRecordingSize(sizeLong)

        assertTrue(formattedShort.endsWith("MB"))
        assertTrue(formattedMedium.endsWith("MB"))
        assertTrue(formattedLong.endsWith("MB"))
    }

    @Test
    fun testLegacyPlaceholderRecalculation() {
        // Legacy recording that previously had the 0.5 MB placeholder (524288 bytes)
        val legacy10MinRec = com.example.data.model.RecordingEntity(
            title = "Legacy 10 Min Stream",
            filePath = "/dummy/legacy.mp4",
            durationMs = 600_000L,
            fileSizeBytes = 524288L, // 0.5 MB old bug placeholder
            resolution = "1080p FHD",
            fps = 60,
            createdAt = System.currentTimeMillis()
        )

        val effectiveSize = com.example.ui.recordings.getEffectiveRecordingSize(legacy10MinRec)
        // Must NOT remain 524288L (0.5 MB)
        assertTrue("Legacy 10-minute recording should not stay at 0.5 MB", effectiveSize > 524288L)
        assertTrue("Legacy 10-minute recording should reflect ~459 MB", effectiveSize > 400 * 1024 * 1024)
    }

    @Test
    fun testFormatRecordingSizeUnits() {
        assertEquals("500 KB", com.example.ui.recordings.formatRecordingSize(500 * 1024L))
        assertEquals("45.5 MB", com.example.ui.recordings.formatRecordingSize((45.5 * 1024 * 1024).toLong()))
        assertEquals("1.50 GB", com.example.ui.recordings.formatRecordingSize((1.5 * 1024 * 1024 * 1024).toLong()))
    }
}
