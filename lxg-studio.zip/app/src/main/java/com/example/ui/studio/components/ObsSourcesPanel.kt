package com.example.ui.studio.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.ScreenShare
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.obs.ObsScene
import com.example.data.model.obs.ObsSource
import com.example.data.model.obs.SourceType
import com.example.ui.theme.StudioAudioGreen
import com.example.ui.theme.StudioCyanAccent
import com.example.ui.theme.StudioLiveRed
import com.example.ui.theme.StudioPurplePrimary
import com.example.ui.theme.StudioRecordAmber
import com.example.ui.theme.StudioSurfaceBorder
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary

@Composable
fun ObsSourcesPanel(
    activeScene: ObsScene?,
    selectedSource: ObsSource?,
    onSelectSource: (ObsSource?) -> Unit,
    onToggleVisibility: (String) -> Unit,
    onToggleLock: (String) -> Unit,
    onRemoveSource: (String) -> Unit,
    onAddSource: (SourceType, String?) -> Unit,
    onBringForward: (String) -> Unit,
    onSendBackward: (String) -> Unit,
    onUpdateSourceProperties: (sourceId: String, text: String?, opacity: Float?, shape: String?) -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddSourceDialog by remember { mutableStateOf(false) }
    var sourceToEdit by remember { mutableStateOf<ObsSource?>(null) }

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SOURCES & OVERLAYS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = StudioTextMuted,
                letterSpacing = 1.sp
            )

            Button(
                onClick = { showAddSourceDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = StudioPurplePrimary),
                shape = RoundedCornerShape(8.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier
                    .height(28.dp)
                    .testTag("add_source_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add Source", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Sources List
        val sources = activeScene?.sources ?: emptyList()
        if (sources.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("No sources in this scene. Tap '+ Add Source' to begin.", fontSize = 11.sp, color = StudioTextMuted)
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                sources.forEach { source ->
                    val isSelected = selectedSource?.id == source.id
                    val icon = getSourceIcon(source.type)

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSelected) StudioSurfaceElevated else Color(0xFF141724),
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) StudioCyanAccent else StudioSurfaceBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onSelectSource(source)
                                sourceToEdit = source
                            }
                            .testTag("source_row_${source.id}")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Left: Icon + Name
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = null,
                                    tint = if (source.isVisible) StudioCyanAccent else StudioTextMuted,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = source.name,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (source.isVisible) StudioTextPrimary else StudioTextMuted
                                    )
                                    Text(
                                        text = "${source.type.displayName} • ${(source.opacity * 100).toInt()}%",
                                        fontSize = 9.sp,
                                        color = StudioTextMuted
                                    )
                                }
                            }

                            // Right: Layer Controls & Actions
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Layer Up
                                IconButton(
                                    onClick = { onBringForward(source.id) },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ArrowUpward,
                                        contentDescription = "Bring Forward",
                                        tint = StudioTextSecondary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }

                                // Layer Down
                                IconButton(
                                    onClick = { onSendBackward(source.id) },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ArrowDownward,
                                        contentDescription = "Send Backward",
                                        tint = StudioTextSecondary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }

                                // Lock Toggle
                                IconButton(
                                    onClick = { onToggleLock(source.id) },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(
                                        imageVector = if (source.isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                                        contentDescription = "Toggle Lock",
                                        tint = if (source.isLocked) StudioRecordAmber else StudioTextSecondary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }

                                // Visibility Toggle
                                IconButton(
                                    onClick = { onToggleVisibility(source.id) },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(
                                        imageVector = if (source.isVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = "Toggle Visibility",
                                        tint = if (source.isVisible) StudioCyanAccent else StudioTextMuted,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }

                                // Delete Source
                                IconButton(
                                    onClick = { onRemoveSource(source.id) },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete Source",
                                        tint = StudioLiveRed.copy(0.7f),
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Source Dialog
    if (showAddSourceDialog) {
        AlertDialog(
            onDismissRequest = { showAddSourceDialog = false },
            containerColor = StudioSurfaceElevated,
            title = {
                Text(
                    text = "Add OBS Source / Widget",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = StudioTextPrimary
                )
            },
            text = {
                val availableSources = listOf(
                    SourceType.SCREEN_CAPTURE to "Android Screen Projection",
                    SourceType.CAMERA_PIP to "Camera PIP (Front / Back Facecam)",
                    SourceType.CHAT_OVERLAY to "Live Chat Overlay HUD",
                    SourceType.ALERT_BOX to "Stream Alerts (Follower / Sub)",
                    SourceType.COUNTDOWN_TIMER to "Countdown Timer Widget",
                    SourceType.VIEWER_COUNTER to "Live Viewer Metric HUD",
                    SourceType.IMAGE_LOGO to "Logo / Branded Watermark",
                    SourceType.TEXT_LABEL to "Text Label / Social Handle",
                    SourceType.BROWSER_WIDGET to "Browser / Web Stream Widget"
                )

                LazyColumn(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(availableSources) { (type, description) ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF141724),
                            border = BorderStroke(1.dp, StudioSurfaceBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onAddSource(type, null)
                                    showAddSourceDialog = false
                                }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(10.dp)
                            ) {
                                Icon(
                                    imageVector = getSourceIcon(type),
                                    contentDescription = null,
                                    tint = StudioCyanAccent,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = type.displayName,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = StudioTextPrimary
                                    )
                                    Text(
                                        text = description,
                                        fontSize = 10.sp,
                                        color = StudioTextMuted
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showAddSourceDialog = false }) {
                    Text("Close", color = StudioTextSecondary)
                }
            }
        )
    }

    // Source Inspector / Properties Dialog
    sourceToEdit?.let { src ->
        var editText by remember { mutableStateOf(src.textContent) }
        var editOpacity by remember { mutableStateOf(src.opacity) }
        var editShape by remember { mutableStateOf(src.shapeType) }

        AlertDialog(
            onDismissRequest = { sourceToEdit = null },
            containerColor = StudioSurfaceElevated,
            title = {
                Text(
                    text = "Edit Source: ${src.name}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = StudioTextPrimary
                )
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    if (src.type == SourceType.TEXT_LABEL || src.type == SourceType.IMAGE_LOGO || src.type == SourceType.ALERT_BOX || src.type == SourceType.VIEWER_COUNTER) {
                        Text("Content / Text Label:", fontSize = 11.sp, color = StudioTextMuted)
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedTextField(
                            value = editText,
                            onValueChange = { editText = it },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    Text("Opacity: ${(editOpacity * 100).toInt()}%", fontSize = 11.sp, color = StudioTextMuted)
                    Slider(
                        value = editOpacity,
                        onValueChange = { editOpacity = it },
                        valueRange = 0.1f..1.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = StudioCyanAccent,
                            activeTrackColor = StudioCyanAccent
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    if (src.type == SourceType.CAMERA_PIP) {
                        Text("PIP Cutout Shape:", fontSize = 11.sp, color = StudioTextMuted)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("ROUNDED" to "Rounded", "CIRCLE" to "Circle", "RECTANGLE" to "Square").forEach { (shape, label) ->
                                Button(
                                    onClick = { editShape = shape },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (editShape == shape) StudioPurplePrimary else StudioSurfaceBorder
                                    ),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Text(label, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onUpdateSourceProperties(src.id, editText, editOpacity, editShape)
                        sourceToEdit = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StudioPurplePrimary)
                ) {
                    Text("Apply Changes", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { sourceToEdit = null }) {
                    Text("Cancel", color = StudioTextSecondary)
                }
            }
        )
    }
}

private fun getSourceIcon(type: SourceType): ImageVector {
    return when (type) {
        SourceType.SCREEN_CAPTURE -> Icons.Default.ScreenShare
        SourceType.CAMERA_PIP -> Icons.Default.Videocam
        SourceType.IMAGE_LOGO -> Icons.Default.Image
        SourceType.TEXT_LABEL -> Icons.Default.TextFields
        SourceType.CHAT_OVERLAY -> Icons.Default.Chat
        SourceType.ALERT_BOX -> Icons.Default.Notifications
        SourceType.COUNTDOWN_TIMER -> Icons.Default.Timer
        SourceType.VIEWER_COUNTER -> Icons.Default.People
        SourceType.BROWSER_WIDGET -> Icons.Default.Language
        else -> Icons.Default.Settings
    }
}
