package com.example.ui.studio.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.obs.ObsScene
import com.example.ui.theme.StudioCyanAccent
import com.example.ui.theme.StudioLiveRed
import com.example.ui.theme.StudioPurplePrimary
import com.example.ui.theme.StudioSurfaceBorder
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary

@Composable
fun ObsScenesPanel(
    scenes: List<ObsScene>,
    activeScene: ObsScene?,
    onSelectScene: (String) -> Unit,
    onCreateScene: (String) -> Unit,
    onDuplicateScene: () -> Unit,
    onDeleteScene: (String) -> Unit,
    onRenameScene: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var sceneToRename by remember { mutableStateOf<ObsScene?>(null) }
    var showActionMenuForScene by remember { mutableStateOf<ObsScene?>(null) }

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Layers,
                    contentDescription = null,
                    tint = StudioCyanAccent,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "OBS SCENES",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = StudioTextMuted,
                    letterSpacing = 1.sp
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Duplicate active scene button
                IconButton(
                    onClick = onDuplicateScene,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Duplicate Scene",
                        tint = StudioTextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }

                // Add scene button
                IconButton(
                    onClick = { showAddDialog = true },
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(StudioPurplePrimary.copy(alpha = 0.2f))
                        .testTag("add_scene_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Scene",
                        tint = StudioCyanAccent,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Horizontal list of Scene chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(scenes) { scene ->
                val isSelected = scene.id == activeScene?.id
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSelected) StudioPurplePrimary else StudioSurfaceElevated,
                    border = BorderStroke(
                        1.dp,
                        if (isSelected) StudioPurplePrimary else StudioSurfaceBorder
                    ),
                    modifier = Modifier
                        .clickable { onSelectScene(scene.id) }
                        .testTag("obs_scene_chip_${scene.id}")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) StudioCyanAccent else StudioTextMuted)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = scene.name,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) Color.White else StudioTextSecondary
                        )

                        // More actions menu icon
                        Box {
                            IconButton(
                                onClick = { showActionMenuForScene = scene },
                                modifier = Modifier.size(20.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MoreVert,
                                    contentDescription = "Scene Options",
                                    tint = if (isSelected) Color.White else StudioTextMuted,
                                    modifier = Modifier.size(14.dp)
                                )
                            }

                            DropdownMenu(
                                expanded = showActionMenuForScene?.id == scene.id,
                                onDismissRequest = { showActionMenuForScene = null }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Rename Scene") },
                                    leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                    onClick = {
                                        sceneToRename = scene
                                        showActionMenuForScene = null
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Delete Scene", color = StudioLiveRed) },
                                    leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = StudioLiveRed, modifier = Modifier.size(16.dp)) },
                                    onClick = {
                                        onDeleteScene(scene.id)
                                        showActionMenuForScene = null
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Scene Dialog
    if (showAddDialog) {
        var newSceneName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            containerColor = StudioSurfaceElevated,
            title = {
                Text(
                    text = "Create New OBS Scene",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = StudioTextPrimary
                )
            },
            text = {
                Column {
                    Text(
                        text = "Enter a name for the new scene (e.g. Gameplay, Chat, Intermission):",
                        fontSize = 12.sp,
                        color = StudioTextSecondary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newSceneName,
                        onValueChange = { newSceneName = it },
                        placeholder = { Text("Scene Name", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = StudioPurplePrimary,
                            unfocusedBorderColor = StudioSurfaceBorder,
                            focusedTextColor = StudioTextPrimary,
                            unfocusedTextColor = StudioTextPrimary
                        ),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onCreateScene(newSceneName)
                        showAddDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StudioPurplePrimary)
                ) {
                    Text("Add Scene", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel", color = StudioTextSecondary)
                }
            }
        )
    }

    // Rename Scene Dialog
    sceneToRename?.let { scene ->
        var updatedName by remember { mutableStateOf(scene.name) }
        AlertDialog(
            onDismissRequest = { sceneToRename = null },
            containerColor = StudioSurfaceElevated,
            title = {
                Text("Rename Scene", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = StudioTextPrimary)
            },
            text = {
                OutlinedTextField(
                    value = updatedName,
                    onValueChange = { updatedName = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRenameScene(scene.id, updatedName)
                        sceneToRename = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StudioPurplePrimary)
                ) {
                    Text("Save", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { sceneToRename = null }) {
                    Text("Cancel", color = StudioTextSecondary)
                }
            }
        )
    }
}
