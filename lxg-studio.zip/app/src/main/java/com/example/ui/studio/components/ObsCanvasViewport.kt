package com.example.ui.studio.components

import android.content.Context
import android.media.projection.MediaProjectionManager
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.ScreenShare
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.StopScreenShare
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.model.obs.CanvasBackgroundType
import com.example.data.model.obs.CanvasConfig
import com.example.data.model.obs.CanvasOrientation
import com.example.data.model.obs.ObsScene
import com.example.data.model.obs.ObsSource
import com.example.data.model.obs.SourceType
import com.example.ui.theme.StudioAudioGreen
import com.example.ui.theme.StudioCyanAccent
import com.example.ui.theme.StudioDarkBg
import com.example.ui.theme.StudioLiveRed
import com.example.ui.theme.StudioPurplePrimary
import com.example.ui.theme.StudioRecordAmber
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceBorder
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun ObsCanvasViewport(
    canvasConfig: CanvasConfig,
    activeScene: ObsScene?,
    selectedSource: ObsSource?,
    isLive: Boolean,
    isScreenCaptureActive: Boolean,
    cameraSelector: CameraSelector,
    hasCameraPermission: Boolean,
    onRequestScreenCapture: () -> Unit,
    onSelectSource: (ObsSource?) -> Unit,
    onUpdateSourceTransform: (sourceId: String, x: Float, y: Float, w: Float, h: Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val aspectRatio = canvasConfig.orientation.aspectRatio
    val isVertical = canvasConfig.orientation == CanvasOrientation.VERTICAL_9_16

    val backgroundBrush = when (canvasConfig.backgroundType) {
        CanvasBackgroundType.SOLID_BLACK -> Brush.linearGradient(listOf(Color.Black, Color.Black))
        CanvasBackgroundType.CYBER_GRADIENT -> Brush.linearGradient(
            listOf(Color(0xFF0F172A), Color(0xFF1E1B4B), Color(0xFF0F172A))
        )
        CanvasBackgroundType.BLUR_BACKGROUND -> Brush.radialGradient(
            listOf(Color(0xFF1E293B), Color(0xFF020617))
        )
        CanvasBackgroundType.SOLID_DARK -> Brush.linearGradient(
            listOf(Color(0xFF0B0F19), Color(0xFF111827))
        )
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(aspectRatio)
            .testTag("obs_canvas_viewport"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Black),
        border = BorderStroke(
            1.5.dp,
            if (isLive) StudioLiveRed else StudioSurfaceBorder
        )
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(backgroundBrush)
                .clickable { onSelectSource(null) }
        ) {
            val canvasWidthPx = constraints.maxWidth.toFloat()
            val canvasHeightPx = constraints.maxHeight.toFloat()

            val sortedSources = activeScene?.sources
                ?.filter { it.isVisible }
                ?.sortedBy { it.zIndex } ?: emptyList()

            // Render all active OBS sources
            sortedSources.forEach { source ->
                val isSelected = selectedSource?.id == source.id
                val xPos = (source.xPercent * canvasWidthPx).roundToInt()
                val yPos = (source.yPercent * canvasHeightPx).roundToInt()
                val wDp = (source.widthPercent * maxWidth.value).dp
                val hDp = (source.heightPercent * maxHeight.value).dp

                Box(
                    modifier = Modifier
                        .offset { IntOffset(xPos, yPos) }
                        .size(width = wDp, height = hDp)
                        .alpha(source.opacity)
                        .clip(
                            if (source.shapeType == "CIRCLE") CircleShape
                            else if (source.shapeType == "ROUNDED") RoundedCornerShape(8.dp)
                            else RoundedCornerShape(0.dp)
                        )
                        .then(
                            if (isSelected) {
                                Modifier.border(2.dp, StudioCyanAccent, RoundedCornerShape(8.dp))
                            } else Modifier
                        )
                        .clickable { onSelectSource(source) }
                        .pointerInput(source.id, source.isLocked) {
                            if (!source.isLocked) {
                                detectDragGestures { change, dragAmount ->
                                    change.consume()
                                    val deltaXPercent = dragAmount.x / canvasWidthPx
                                    val deltaYPercent = dragAmount.y / canvasHeightPx
                                    val newX = (source.xPercent + deltaXPercent).coerceIn(0.0f, 1.0f - source.widthPercent)
                                    val newY = (source.yPercent + deltaYPercent).coerceIn(0.0f, 1.0f - source.heightPercent)
                                    onUpdateSourceTransform(source.id, newX, newY, source.widthPercent, source.heightPercent)
                                }
                            }
                        }
                ) {
                    when (source.type) {
                        SourceType.SCREEN_CAPTURE -> {
                            ScreenCaptureSourceView(
                                isCapturing = isScreenCaptureActive,
                                onRequestCapture = onRequestScreenCapture
                            )
                        }
                        SourceType.CAMERA_PIP -> {
                            CameraPipSourceView(
                                hasCameraPermission = hasCameraPermission,
                                cameraSelector = cameraSelector
                            )
                        }
                        SourceType.BACKGROUND -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.radialGradient(
                                            listOf(Color(0xFF312E81), Color(0xFF0F172A))
                                        )
                                    )
                            )
                        }
                        SourceType.IMAGE_LOGO -> {
                            Surface(
                                color = Color.Black.copy(alpha = 0.65f),
                                shape = RoundedCornerShape(6.dp),
                                border = BorderStroke(1.dp, StudioCyanAccent.copy(0.6f)),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center,
                                    modifier = Modifier.padding(horizontal = 6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(StudioCyanAccent)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = source.textContent.ifBlank { "LXG STUDIO" },
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color.White,
                                        letterSpacing = 0.8.sp
                                    )
                                }
                            }
                        }
                        SourceType.TEXT_LABEL -> {
                            val bgColor = try {
                                Color(android.graphics.Color.parseColor(source.backgroundColorHex)).copy(alpha = 0.85f)
                            } catch (e: Exception) {
                                Color(0xFF1E293B).copy(alpha = 0.85f)
                            }
                            val txtColor = try {
                                Color(android.graphics.Color.parseColor(source.textColorHex))
                            } catch (e: Exception) {
                                Color.White
                            }
                            Surface(
                                color = bgColor,
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                Box(
                                    contentAlignment = Alignment.CenterStart,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = source.textContent,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = txtColor
                                    )
                                }
                            }
                        }
                        SourceType.ALERT_BOX -> {
                            Surface(
                                color = Color.Black.copy(0.8f),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, StudioAudioGreen),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = StudioAudioGreen,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = source.textContent.ifBlank { "★ New Subscriber!" },
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                        SourceType.CHAT_OVERLAY -> {
                            Surface(
                                color = Color.Black.copy(0.75f),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, Color(0xFF334155)),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                Column(modifier = Modifier.padding(6.dp)) {
                                    Text(
                                        text = "LIVE CHAT HUD",
                                        fontSize = 7.sp,
                                        fontWeight = FontWeight.Black,
                                        color = StudioCyanAccent
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "ApexPro: Let's go live!",
                                        fontSize = 8.sp,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "Sarah99: Audio sounds crystal clear",
                                        fontSize = 8.sp,
                                        color = Color(0xFFCBD5E1)
                                    )
                                }
                            }
                        }
                        SourceType.COUNTDOWN_TIMER -> {
                            Surface(
                                color = Color.Black.copy(0.85f),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, StudioPurplePrimary),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center,
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Timer,
                                        contentDescription = null,
                                        tint = StudioCyanAccent,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    val mins = source.timerSecondsRemaining / 60
                                    val secs = source.timerSecondsRemaining % 60
                                    Text(
                                        text = String.format(Locale.US, "%02d:%02d", mins, secs),
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Black,
                                        fontFamily = FontFamily.Monospace,
                                        color = StudioCyanAccent
                                    )
                                }
                            }
                        }
                        SourceType.VIEWER_COUNTER -> {
                            Surface(
                                color = Color.Black.copy(0.75f),
                                shape = RoundedCornerShape(6.dp),
                                border = BorderStroke(1.dp, StudioLiveRed.copy(0.8f)),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center,
                                    modifier = Modifier.padding(horizontal = 6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(StudioLiveRed)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = source.textContent.ifBlank { "LIVE 2.4k" },
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Black,
                                        fontFamily = FontFamily.Monospace,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                        else -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(StudioSurface)
                                    .border(1.dp, StudioSurfaceBorder),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(source.name, fontSize = 9.sp, color = StudioTextSecondary)
                            }
                        }
                    }

                    // Lock Icon overlay if locked
                    if (source.isLocked) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(2.dp)
                                .size(14.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(0.7f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Locked",
                                tint = StudioRecordAmber,
                                modifier = Modifier.size(9.dp)
                            )
                        }
                    }
                }
            }

            // Safe Zone Guides
            if (canvasConfig.showSafeZones) {
                if (isVertical) {
                    // 9:16 Shorts / Reels / TikTok UI Safe Area
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(top = 40.dp, bottom = 60.dp, start = 16.dp, end = 50.dp)
                            .border(1.dp, StudioCyanAccent.copy(alpha = 0.35f), RoundedCornerShape(4.dp))
                    ) {
                        Text(
                            text = "9:16 SHORTS SAFE ZONE",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = StudioCyanAccent.copy(alpha = 0.7f),
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(4.dp)
                        )
                    }
                } else {
                    // 16:9 Title & Action Safe Zone
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 24.dp, vertical = 14.dp)
                            .border(1.dp, StudioCyanAccent.copy(alpha = 0.35f), RoundedCornerShape(4.dp))
                    ) {
                        Text(
                            text = "16:9 TITLE SAFE ZONE",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = StudioCyanAccent.copy(alpha = 0.7f),
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ScreenCaptureSourceView(
    isCapturing: Boolean,
    onRequestCapture: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0F1D)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(8.dp)
        ) {
            Icon(
                imageVector = if (isCapturing) Icons.Default.ScreenShare else Icons.Default.StopScreenShare,
                contentDescription = null,
                tint = if (isCapturing) StudioCyanAccent else StudioTextMuted,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (isCapturing) "Android Screen Capture Active" else "Screen Source Standby",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = StudioTextPrimary
            )
            Text(
                text = if (isCapturing) "Streaming device screen & gameplay" else "Tap below to grant MediaProjection",
                fontSize = 9.sp,
                color = StudioTextMuted
            )
            if (!isCapturing) {
                Spacer(modifier = Modifier.height(6.dp))
                Button(
                    onClick = onRequestCapture,
                    shape = RoundedCornerShape(6.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = StudioCyanAccent),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.height(28.dp)
                ) {
                    Text("Grant Screen Access", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                }
            }
        }
    }
}

@Composable
private fun CameraPipSourceView(
    hasCameraPermission: Boolean,
    cameraSelector: CameraSelector
) {
    val lifecycleOwner = LocalLifecycleOwner.current

    if (hasCameraPermission) {
        AndroidView(
            factory = { ctx ->
                val previewView = PreviewView(ctx).apply {
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                }
                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                cameraProviderFuture.addListener({
                    try {
                        val cameraProvider = cameraProviderFuture.get()
                        val preview = Preview.Builder().build().also {
                            it.setSurfaceProvider(previewView.surfaceProvider)
                        }
                        cameraProvider.unbindAll()
                        cameraProvider.bindToLifecycle(
                            lifecycleOwner,
                            cameraSelector,
                            preview
                        )
                    } catch (e: Exception) {
                        // ignore bind exceptions
                    }
                }, ContextCompat.getMainExecutor(ctx))
                previewView
            },
            modifier = Modifier.fillMaxSize()
        )
    } else {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Videocam,
                contentDescription = null,
                tint = StudioTextMuted,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}
