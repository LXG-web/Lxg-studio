package com.example.ui.destinations

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Podcasts
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DestinationEntity
import com.example.ui.MainViewModel
import com.example.ui.theme.StudioAudioGreen
import com.example.ui.theme.StudioAudioYellow
import com.example.ui.theme.StudioCyanAccent
import com.example.ui.theme.StudioDarkBg
import com.example.ui.theme.StudioLiveRed
import com.example.ui.theme.StudioPurplePrimary
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceBorder
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary

@Composable
fun DestinationsScreen(viewModel: MainViewModel) {
    val destinations by viewModel.destinations.collectAsState()
    val showAddDialog by viewModel.showAddDestinationDialog.collectAsState()
    val destinationForEdit by viewModel.destinationForEdit.collectAsState()

    var destinationToDelete by remember { mutableStateOf<DestinationEntity?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioDarkBg)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 28.dp)
    ) {
        // Keystore Security & Multi-stream Header
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("keystore_security_badge"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioPurplePrimary.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(StudioPurplePrimary.copy(0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = StudioPurplePrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Android Keystore Encrypted",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = StudioTextPrimary
                        )
                        Text(
                            text = "Stream keys are secured with hardware AES-256-GCM. Unencrypted keys are never logged or exposed.",
                            fontSize = 11.sp,
                            color = StudioTextMuted
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Actions Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "BROADCAST DESTINATIONS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = StudioTextMuted,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = "Multi-Streaming Ready",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        color = StudioTextPrimary
                    )
                }

                Button(
                    onClick = { viewModel.openAddDestinationDialog(null) },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = StudioPurplePrimary),
                    modifier = Modifier.testTag("add_destination_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Add RTMP", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // List of Destinations
        if (destinations.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Podcasts,
                            contentDescription = null,
                            tint = StudioTextMuted,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No destinations saved",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = StudioTextSecondary
                        )
                        Text(
                            text = "Add YouTube, Twitch, Facebook or Custom RTMP server to start broadcasting",
                            fontSize = 11.sp,
                            color = StudioTextMuted
                        )
                    }
                }
            }
        } else {
            items(destinations, key = { it.id }) { destination ->
                DestinationCard(
                    destination = destination,
                    onToggleEnabled = { viewModel.toggleDestination(destination) },
                    onTestPing = { viewModel.testDestinationPing(destination) },
                    onEdit = { viewModel.openAddDestinationDialog(destination) },
                    onDelete = { destinationToDelete = destination }
                )
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }

    // Add / Edit Destination Modal
    if (showAddDialog) {
        AddEditDestinationDialog(
            target = destinationForEdit,
            onDismiss = { viewModel.closeAddDestinationDialog() },
            onSave = { platform, label, url, key ->
                viewModel.saveDestination(
                    id = destinationForEdit?.id ?: 0L,
                    platformName = platform,
                    label = label,
                    serverUrl = url,
                    streamKey = key
                )
            }
        )
    }

    // Delete Confirmation Dialog
    destinationToDelete?.let { dest ->
        AlertDialog(
            onDismissRequest = { destinationToDelete = null },
            containerColor = StudioSurfaceElevated,
            title = {
                Text(
                    text = "Delete Destination?",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = StudioTextPrimary
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to remove '${dest.label}'? You will need to re-enter its stream key if you wish to add it again.",
                    fontSize = 13.sp,
                    color = StudioTextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteDestination(dest)
                        destinationToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StudioLiveRed),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Delete", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { destinationToDelete = null }) {
                    Text("Cancel", color = StudioTextSecondary)
                }
            }
        )
    }
}

@Composable
private fun DestinationCard(
    destination: DestinationEntity,
    onToggleEnabled: () -> Unit,
    onTestPing: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("destination_card_${destination.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (destination.isEnabled) StudioPurplePrimary.copy(alpha = 0.6f) else StudioSurfaceBorder
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row: Label & Platform Badge + Multi-stream Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (destination.isEnabled) StudioAudioGreen else StudioTextMuted)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = destination.label,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = StudioTextPrimary
                        )
                        Text(
                            text = destination.platformName,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = StudioCyanAccent
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (destination.isEnabled) "ACTIVE" else "STANDBY",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (destination.isEnabled) StudioAudioGreen else StudioTextMuted
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Switch(
                        checked = destination.isEnabled,
                        onCheckedChange = { onToggleEnabled() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = StudioPurplePrimary,
                            uncheckedThumbColor = StudioTextMuted,
                            uncheckedTrackColor = StudioSurface
                        ),
                        modifier = Modifier.testTag("dest_switch_${destination.id}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Server URL row
            Text(
                text = "SERVER ENDPOINT",
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = StudioTextMuted,
                letterSpacing = 1.sp
            )
            Text(
                text = destination.serverUrl,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                color = StudioTextSecondary,
                maxLines = 1
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Stream Key (Masked with Lock icon)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Encrypted",
                        tint = StudioPurplePrimary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "STREAM KEY: ${destination.maskedKey}",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = StudioTextMuted
                    )
                }

                // Ping Status
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { onTestPing() }
                ) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = "Ping",
                        tint = if (destination.lastPingMs > 0) StudioAudioGreen else StudioTextMuted,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (destination.lastPingMs > 0) "${destination.lastPingMs}ms" else "Test Socket",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (destination.lastPingMs > 0) StudioAudioGreen else StudioCyanAccent
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                IconButton(
                    onClick = onEdit,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Edit",
                        tint = StudioTextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete",
                        tint = StudioLiveRed.copy(alpha = 0.8f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun AddEditDestinationDialog(
    target: DestinationEntity?,
    onDismiss: () -> Unit,
    onSave: (platform: String, label: String, url: String, key: String) -> Unit
) {
    val platforms = listOf("YouTube Live", "Twitch", "Facebook Live", "Custom RTMP", "Custom RTMPS")
    var selectedPlatform by remember { mutableStateOf(target?.platformName ?: "YouTube Live") }
    var label by remember { mutableStateOf(target?.label ?: "YouTube Stream") }
    var serverUrl by remember {
        mutableStateOf(
            target?.serverUrl ?: when (selectedPlatform) {
                "YouTube Live" -> "rtmp://a.rtmp.youtube.com/live2"
                "Twitch" -> "rtmp://live.twitch.tv/app/"
                "Facebook Live" -> "rtmps://live-api-s.facebook.com:443/rtmp/"
                "Custom RTMPS" -> "rtmps://"
                else -> "rtmp://"
            }
        )
    }
    var streamKey by remember { mutableStateOf("") }
    var showKeyText by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudioSurfaceElevated,
        title = {
            Text(
                text = if (target == null) "Add Broadcast Destination" else "Edit Destination",
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                color = StudioTextPrimary
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Platform Presets Chips
                Text(
                    text = "SELECT PLATFORM PRESET",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = StudioTextMuted
                )
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(platforms) { p ->
                        val isSel = p == selectedPlatform
                        FilterChip(
                            selected = isSel,
                            onClick = {
                                selectedPlatform = p
                                if (target == null) {
                                    label = "$p Broadcast"
                                    serverUrl = when (p) {
                                        "YouTube Live" -> "rtmp://a.rtmp.youtube.com/live2"
                                        "Twitch" -> "rtmp://live.twitch.tv/app/"
                                        "Facebook Live" -> "rtmps://live-api-s.facebook.com:443/rtmp/"
                                        "Custom RTMPS" -> "rtmps://"
                                        else -> "rtmp://"
                                    }
                                }
                            },
                            label = { Text(text = p, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StudioPurplePrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Label
                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it },
                    label = { Text("Destination Name") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StudioPurplePrimary,
                        unfocusedBorderColor = StudioSurfaceBorder,
                        focusedTextColor = StudioTextPrimary,
                        unfocusedTextColor = StudioTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Server URL
                OutlinedTextField(
                    value = serverUrl,
                    onValueChange = { serverUrl = it },
                    label = { Text("RTMP Server URL") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StudioPurplePrimary,
                        unfocusedBorderColor = StudioSurfaceBorder,
                        focusedTextColor = StudioTextPrimary,
                        unfocusedTextColor = StudioTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Stream Key
                OutlinedTextField(
                    value = streamKey,
                    onValueChange = { streamKey = it },
                    label = { Text(if (target != null && streamKey.isEmpty()) "Keep existing key or enter new" else "Stream Key (Encrypted in Keystore)") },
                    visualTransformation = if (showKeyText) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showKeyText = !showKeyText }) {
                            Icon(
                                imageVector = if (showKeyText) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = "Toggle Visibility",
                                tint = StudioTextMuted
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StudioPurplePrimary,
                        unfocusedBorderColor = StudioSurfaceBorder,
                        focusedTextColor = StudioTextPrimary,
                        unfocusedTextColor = StudioTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = StudioPurplePrimary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Key will be encrypted with Android Hardware Keystore AES-256.",
                        fontSize = 10.sp,
                        color = StudioTextMuted
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (serverUrl.isNotBlank()) {
                        val keyToUse = if (streamKey.isBlank() && target != null) {
                            "retained_key"
                        } else {
                            streamKey
                        }
                        onSave(selectedPlatform, label, serverUrl, keyToUse)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = StudioPurplePrimary),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Save Destination", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = StudioTextSecondary)
            }
        }
    )
}
