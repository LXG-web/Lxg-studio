package com.example.ui.studio.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CropLandscape
import androidx.compose.material.icons.filled.CropPortrait
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.obs.CanvasBackgroundType
import com.example.data.model.obs.CanvasConfig
import com.example.data.model.obs.CanvasOrientation
import com.example.data.model.obs.CanvasPreset
import com.example.data.model.obs.CanvasScaleMode
import com.example.ui.theme.StudioCyanAccent
import com.example.ui.theme.StudioPurplePrimary
import com.example.ui.theme.StudioSurfaceBorder
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary

@Composable
fun ObsCanvasSettingsDialog(
    canvasConfig: CanvasConfig,
    onDismiss: () -> Unit,
    onSetOrientation: (CanvasOrientation) -> Unit,
    onSetPreset: (CanvasPreset) -> Unit,
    onSetScaleMode: (CanvasScaleMode) -> Unit,
    onSetBackgroundType: (CanvasBackgroundType) -> Unit,
    onToggleSafeZones: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudioSurfaceElevated,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = null,
                    tint = StudioCyanAccent,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Studio Canvas & Production Setup",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = StudioTextPrimary
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // 1. Orientation Mode (Short-form vs Long-form)
                Text(
                    text = "PRODUCTION ORIENTATION MODE",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = StudioTextMuted
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val isHorizontal = canvasConfig.orientation == CanvasOrientation.HORIZONTAL_16_9
                    // Horizontal 16:9
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isHorizontal) StudioPurplePrimary else Color(0xFF141724),
                        border = BorderStroke(1.dp, if (isHorizontal) StudioPurplePrimary else StudioSurfaceBorder),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onSetOrientation(CanvasOrientation.HORIZONTAL_16_9) }
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CropLandscape,
                                contentDescription = null,
                                tint = if (isHorizontal) Color.White else StudioCyanAccent,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("16:9 Horizontal", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White)
                            Text("Long Feed / YouTube", fontSize = 9.sp, color = if (isHorizontal) Color(0xFFE2E8F0) else StudioTextMuted)
                        }
                    }

                    // Vertical 9:16
                    val isVertical = canvasConfig.orientation == CanvasOrientation.VERTICAL_9_16
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isVertical) StudioPurplePrimary else Color(0xFF141724),
                        border = BorderStroke(1.dp, if (isVertical) StudioPurplePrimary else StudioSurfaceBorder),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onSetOrientation(CanvasOrientation.VERTICAL_9_16) }
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CropPortrait,
                                contentDescription = null,
                                tint = if (isVertical) Color.White else StudioCyanAccent,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("9:16 Vertical", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White)
                            Text("Shorts / Reels / TikTok", fontSize = 9.sp, color = if (isVertical) Color(0xFFE2E8F0) else StudioTextMuted)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 2. Resolution Presets for the selected orientation
                Text(
                    text = "CANVAS RESOLUTION PRESET",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = StudioTextMuted
                )
                Spacer(modifier = Modifier.height(6.dp))
                val relevantPresets = CanvasPreset.values().filter { it.orientation == canvasConfig.orientation }
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    relevantPresets.forEach { preset ->
                        val isPresetSelected = canvasConfig.preset == preset
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (isPresetSelected) Color(0xFF1E1B4B) else Color(0xFF141724),
                            border = BorderStroke(1.dp, if (isPresetSelected) StudioCyanAccent else StudioSurfaceBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSetPreset(preset) }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(preset.label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = StudioTextPrimary)
                                if (isPresetSelected) {
                                    Text("ACTIVE", fontSize = 9.sp, fontWeight = FontWeight.Black, color = StudioCyanAccent)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 3. Canvas Scaling Mode
                Text(
                    text = "SCALING & FIT",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = StudioTextMuted
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CanvasScaleMode.values().forEach { mode ->
                        val isSelected = canvasConfig.scaleMode == mode
                        Button(
                            onClick = { onSetScaleMode(mode) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) StudioPurplePrimary else Color(0xFF141724)
                            ),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.height(26.dp)
                        ) {
                            Text(mode.label.substringBefore(" ("), fontSize = 9.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 4. Safe Zones Guides
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Display Safe Area Guides", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = StudioTextPrimary)
                        Text(
                            if (canvasConfig.orientation == CanvasOrientation.VERTICAL_9_16) "Shorts / Reels UI icon overlay margins"
                            else "Broadcast 16:9 Title & Action safe boundaries",
                            fontSize = 9.sp,
                            color = StudioTextMuted
                        )
                    }
                    Switch(
                        checked = canvasConfig.showSafeZones,
                        onCheckedChange = { onToggleSafeZones() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = StudioPurplePrimary
                        )
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = StudioPurplePrimary)
            ) {
                Text("Done", fontWeight = FontWeight.Bold)
            }
        }
    )
}
