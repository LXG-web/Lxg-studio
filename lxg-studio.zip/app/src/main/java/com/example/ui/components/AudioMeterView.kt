package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.AudioMeterState
import com.example.ui.theme.StudioAudioGreen
import com.example.ui.theme.StudioAudioYellow
import com.example.ui.theme.StudioLiveRed
import com.example.ui.theme.StudioPurplePrimary
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceBorder
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import java.util.Locale

@Composable
fun AudioMeterView(
    audioMeter: AudioMeterState,
    isMuted: Boolean,
    gainPercent: Int,
    onToggleMute: () -> Unit,
    onGainChanged: (Int) -> Unit
) {
    val animatedLeft by animateFloatAsState(targetValue = if (isMuted) 0f else audioMeter.leftLevel, label = "L")
    val animatedRight by animateFloatAsState(targetValue = if (isMuted) 0f else audioMeter.rightLevel, label = "R")

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("audio_meter_card"),
        colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(if (isMuted) StudioLiveRed.copy(0.2f) else StudioPurplePrimary.copy(0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                            contentDescription = "Microphone",
                            tint = if (isMuted) StudioLiveRed else StudioPurplePrimary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Audio Console (VU)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = StudioTextPrimary
                        )
                        Text(
                            text = if (isMuted) "MUTED" else "Gain: $gainPercent%",
                            fontSize = 11.sp,
                            color = if (isMuted) StudioLiveRed else StudioTextSecondary
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (isMuted) "-INF dB" else String.format(Locale.US, "%.1f dB", audioMeter.peakDb),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (audioMeter.isClipping) StudioLiveRed else StudioAudioGreen
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = onToggleMute,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(StudioSurface)
                            .testTag("mute_mic_button")
                    ) {
                        Icon(
                            imageVector = if (isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                            contentDescription = if (isMuted) "Unmute" else "Mute",
                            tint = if (isMuted) StudioLiveRed else StudioTextPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // VU Bar Left Channel
            VULine(label = "L", fillRatio = animatedLeft)
            Spacer(modifier = Modifier.height(6.dp))
            // VU Bar Right Channel
            VULine(label = "R", fillRatio = animatedRight)

            Spacer(modifier = Modifier.height(10.dp))

            // Gain Slider
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "MIC GAIN",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = StudioTextMuted,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Slider(
                    value = gainPercent.toFloat(),
                    onValueChange = { onGainChanged(it.toInt()) },
                    valueRange = 0f..100f,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("mic_gain_slider"),
                    colors = SliderDefaults.colors(
                        thumbColor = StudioPurplePrimary,
                        activeTrackColor = StudioPurplePrimary,
                        inactiveTrackColor = StudioSurfaceBorder
                    )
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "$gainPercent%",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = StudioTextSecondary
                )
            }
        }
    }
}

@Composable
private fun VULine(label: String, fillRatio: Float) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = StudioTextMuted,
            modifier = Modifier.width(16.dp)
        )
        Box(
            modifier = Modifier
                .weight(1f)
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(StudioSurface)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fillRatio.coerceIn(0.01f, 1f))
                    .clip(RoundedCornerShape(4.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                StudioAudioGreen,
                                StudioAudioGreen,
                                StudioAudioYellow,
                                StudioLiveRed
                            )
                        )
                    )
            )
        }
    }
}
