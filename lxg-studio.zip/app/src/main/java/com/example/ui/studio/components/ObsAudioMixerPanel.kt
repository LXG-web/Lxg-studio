package com.example.ui.studio.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.audio.AudioChannelMeter
import com.example.engine.audio.DualAudioMixerState
import com.example.ui.theme.StudioAudioGreen
import com.example.ui.theme.StudioCyanAccent
import com.example.ui.theme.StudioLiveRed
import com.example.ui.theme.StudioPurplePrimary
import com.example.ui.theme.StudioRecordAmber
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceBorder
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import java.util.Locale

@Composable
fun ObsAudioMixerPanel(
    mixerState: DualAudioMixerState,
    micMeter: AudioChannelMeter,
    internalMeter: AudioChannelMeter,
    onSetMicVolume: (Int) -> Unit,
    onToggleMicMute: () -> Unit,
    onSetInternalVolume: (Int) -> Unit,
    onToggleInternalMute: () -> Unit,
    onToggleNoiseSuppression: () -> Unit,
    onToggleAec: () -> Unit,
    onSetAudioDelayMs: (Int) -> Unit,
    onToggleBluetoothSco: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("obs_audio_mixer_panel"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
        border = BorderStroke(1.dp, StudioSurfaceBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = null,
                        tint = StudioCyanAccent,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "AUDIO MIXER & DUAL ROUTING",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = StudioTextMuted,
                        letterSpacing = 1.sp
                    )
                }

                // Dual routing status badge
                Surface(
                    color = if (mixerState.isBluetoothScoActive) Color(0xFF312E81) else StudioSurface,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, if (mixerState.isBluetoothScoActive) StudioCyanAccent else StudioSurfaceBorder)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (mixerState.isBluetoothScoActive) StudioCyanAccent else StudioAudioGreen)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (mixerState.isBluetoothScoActive) "BT SCO Mode" else "Direct Routing",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = StudioTextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Channel 1: Microphone (Voice)
            AudioChannelStrip(
                channelName = "MICROPHONE (VOICE)",
                volumePercent = mixerState.micVolumePercent,
                isMuted = mixerState.isMicMuted,
                meter = micMeter,
                onVolumeChange = onSetMicVolume,
                onToggleMute = onToggleMicMute,
                icon = if (mixerState.isMicMuted) Icons.Default.MicOff else Icons.Default.Mic,
                iconColor = if (mixerState.isMicMuted) StudioLiveRed else StudioAudioGreen,
                maxVolume = 150
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Channel 2: Internal Device / Game Audio
            AudioChannelStrip(
                channelName = "DEVICE / GAME AUDIO",
                volumePercent = mixerState.internalVolumePercent,
                isMuted = mixerState.isInternalMuted,
                meter = internalMeter,
                onVolumeChange = onSetInternalVolume,
                onToggleMute = onToggleInternalMute,
                icon = if (mixerState.isInternalMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                iconColor = if (mixerState.isInternalMuted) StudioLiveRed else StudioCyanAccent,
                maxVolume = 100
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Audio Processing FX: Noise Suppression & AEC & Delay Sync
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Noise Suppression toggle
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = StudioSurface,
                    border = BorderStroke(1.dp, StudioSurfaceBorder),
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Noise Suppr.", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = StudioTextPrimary)
                            Text(
                                if (mixerState.isNoiseSuppressionSupported) "Hardware DSP" else "Disabled",
                                fontSize = 8.sp,
                                color = StudioTextMuted
                            )
                        }
                        Switch(
                            checked = mixerState.isNoiseSuppressionEnabled,
                            onCheckedChange = { onToggleNoiseSuppression() },
                            enabled = mixerState.isNoiseSuppressionSupported,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = StudioPurplePrimary
                            ),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                // Acoustic Echo Canceler toggle
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = StudioSurface,
                    border = BorderStroke(1.dp, StudioSurfaceBorder),
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Echo Cancel", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = StudioTextPrimary)
                            Text(
                                if (mixerState.isAecSupported) "AEC Active" else "Unavailable",
                                fontSize = 8.sp,
                                color = StudioTextMuted
                            )
                        }
                        Switch(
                            checked = mixerState.isAecEnabled,
                            onCheckedChange = { onToggleAec() },
                            enabled = mixerState.isAecSupported,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = StudioPurplePrimary
                            ),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Audio Delay Sync Compensation Slider (0ms to 500ms)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Sync Delay Offset:", fontSize = 10.sp, color = StudioTextMuted)
                Text("${mixerState.audioDelayMs} ms", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = StudioCyanAccent)
            }
            Slider(
                value = mixerState.audioDelayMs.toFloat(),
                onValueChange = { onSetAudioDelayMs(it.toInt()) },
                valueRange = 0f..500f,
                steps = 19,
                colors = SliderDefaults.colors(
                    thumbColor = StudioCyanAccent,
                    activeTrackColor = StudioCyanAccent
                ),
                modifier = Modifier.height(24.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Dual Microphone Routing Helper (Game + Stream concurrency)
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF0F172A),
                border = BorderStroke(1.dp, Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Headphones,
                                contentDescription = null,
                                tint = StudioCyanAccent,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Dual Mic Routing (Game Voice + Stream)",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = StudioTextPrimary
                            )
                        }

                        Button(
                            onClick = onToggleBluetoothSco,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (mixerState.isBluetoothScoActive) StudioCyanAccent else StudioPurplePrimary
                            ),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(26.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Bluetooth,
                                contentDescription = null,
                                tint = if (mixerState.isBluetoothScoActive) Color.Black else Color.White,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (mixerState.isBluetoothScoActive) "SCO Active" else "Enable SCO",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (mixerState.isBluetoothScoActive) Color.Black else Color.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Android allows 1 foreground app exclusive microphone access. When in game voice chat, Bluetooth SCO splits mic streams so both game teammates and stream viewers hear you.",
                        fontSize = 8.sp,
                        color = StudioTextMuted,
                        lineHeight = 11.sp
                    )

                    mixerState.concurrencyWarningMessage?.let { warning ->
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = StudioRecordAmber, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(warning, fontSize = 9.sp, color = StudioRecordAmber)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AudioChannelStrip(
    channelName: String,
    volumePercent: Int,
    isMuted: Boolean,
    meter: AudioChannelMeter,
    onVolumeChange: (Int) -> Unit,
    onToggleMute: () -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color,
    maxVolume: Int
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = StudioSurface,
        border = BorderStroke(1.dp, StudioSurfaceBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            // Channel Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onToggleMute,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = "Mute",
                            tint = iconColor,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = channelName,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isMuted) StudioTextMuted else StudioTextPrimary
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${String.format(Locale.US, "%.1f", meter.peakDb)} dB",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = if (meter.isClipping) StudioLiveRed else StudioTextSecondary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "$volumePercent%",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = if (isMuted) StudioTextMuted else StudioCyanAccent
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // VU Meter Bar (Green to Yellow to Red)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color(0xFF0F172A))
            ) {
                val fillWidthPercent = if (isMuted) 0.0f else meter.levelNorm.coerceIn(0f, 1f)
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(fillWidthPercent)
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    StudioAudioGreen,
                                    StudioAudioGreen,
                                    StudioRecordAmber,
                                    StudioLiveRed
                                )
                            )
                        )
                )
            }

            // Volume Slider
            Slider(
                value = volumePercent.toFloat(),
                onValueChange = { onVolumeChange(it.toInt()) },
                valueRange = 0f..maxVolume.toFloat(),
                colors = SliderDefaults.colors(
                    thumbColor = if (isMuted) StudioTextMuted else StudioCyanAccent,
                    activeTrackColor = if (isMuted) StudioTextMuted else StudioCyanAccent
                ),
                modifier = Modifier.height(24.dp)
            )
        }
    }
}
