package com.example.ui.studio

import android.app.Activity
import android.content.Context
import android.media.projection.MediaProjectionManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.CastConnected
import androidx.compose.material.icons.filled.CropLandscape
import androidx.compose.material.icons.filled.CropPortrait
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.model.obs.CanvasOrientation
import com.example.engine.RecordingStatus
import com.example.engine.ScreenCastStatus
import com.example.engine.StreamStatus
import com.example.ui.MainViewModel
import com.example.ui.studio.components.ObsAudioMixerPanel
import com.example.ui.studio.components.ObsCanvasSettingsDialog
import com.example.ui.studio.components.ObsCanvasViewport
import com.example.ui.studio.components.ObsScenesPanel
import com.example.ui.studio.components.ObsSourcesPanel
import com.example.ui.theme.StudioAudioGreen
import com.example.ui.theme.StudioCyanAccent
import com.example.ui.theme.StudioDarkBg
import com.example.ui.theme.StudioLiveRed
import com.example.ui.theme.StudioPurplePrimary
import com.example.ui.theme.StudioRecordAmber
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceBorder
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary

@Composable
fun StudioScreen(viewModel: MainViewModel) {
    val context = LocalContext.current

    val streamStatus by viewModel.streamStatus.collectAsState()
    val recordingStatus by viewModel.recordingStatus.collectAsState()
    val screenCastStatus by viewModel.screenCastStatus.collectAsState()
    val isFloatingBubbleActive by viewModel.isFloatingBubbleActive.collectAsState()
    val telemetry by viewModel.telemetry.collectAsState()
    val settings by viewModel.streamSettings.collectAsState()
    val cameraSelector by viewModel.cameraSelector.collectAsState()
    val isScreenCaptureActive by viewModel.isScreenCaptureActive.collectAsState()

    // OBS Flows
    val obsScenes by viewModel.obsScenes.collectAsState()
    val activeObsScene by viewModel.activeObsScene.collectAsState()
    val canvasConfig by viewModel.canvasConfig.collectAsState()
    val selectedObsSource by viewModel.selectedObsSource.collectAsState()

    // Audio Flows
    val dualMixerState by viewModel.dualMixerState.collectAsState()
    val dualMicMeter by viewModel.dualMicMeter.collectAsState()
    val dualInternalMeter by viewModel.dualInternalMeter.collectAsState()

    // Studio Dock Tab Selection (0 = Scenes, 1 = Sources, 2 = Audio Mixer)
    var activeDockTabIndex by remember { mutableStateOf(0) }
    var showCanvasSettingsDialog by remember { mutableStateOf(false) }

    // MediaProjection screen capture launcher
    val screenCaptureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            viewModel.streamEngine.setScreenCaptureState(true)
        }
    }

    // Permission launcher for Camera & Mic
    var hasCameraPermission by remember { mutableStateOf(false) }
    var hasMicPermission by remember { mutableStateOf(false) }
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        hasCameraPermission = permissions[android.Manifest.permission.CAMERA] == true
        hasMicPermission = permissions[android.Manifest.permission.RECORD_AUDIO] == true
    }

    LaunchedEffect(Unit) {
        val cam = ContextCompat.checkSelfPermission(context, android.Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED
        val mic = ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED
        hasCameraPermission = cam
        hasMicPermission = mic
        if (!cam || !mic) {
            permissionLauncher.launch(
                arrayOf(
                    android.Manifest.permission.CAMERA,
                    android.Manifest.permission.RECORD_AUDIO
                )
            )
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioDarkBg)
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .testTag("studio_screen_content"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Studio Top Header with Layout Selector (16:9 vs 9:16)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (streamStatus == StreamStatus.LIVE) StudioLiveRed else StudioAudioGreen)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "OBS STUDIO",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        letterSpacing = 1.2.sp
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Orientation Mode Switcher Chip (Horizontal 16:9 vs Vertical 9:16)
                    val isHorizontal = canvasConfig.orientation == CanvasOrientation.HORIZONTAL_16_9
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = StudioSurfaceElevated,
                        border = BorderStroke(1.dp, StudioCyanAccent),
                        modifier = Modifier
                            .clickable {
                                val next = if (isHorizontal) CanvasOrientation.VERTICAL_9_16 else CanvasOrientation.HORIZONTAL_16_9
                                viewModel.setCanvasOrientation(next)
                            }
                            .testTag("orientation_switch_chip")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = if (isHorizontal) Icons.Default.CropLandscape else Icons.Default.CropPortrait,
                                contentDescription = null,
                                tint = StudioCyanAccent,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isHorizontal) "16:9 Long" else "9:16 Short",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    // Canvas Settings / Safe Area Gear button
                    IconButton(
                        onClick = { showCanvasSettingsDialog = true },
                        modifier = Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(StudioSurfaceElevated)
                            .border(1.dp, StudioSurfaceBorder, CircleShape)
                            .testTag("canvas_settings_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "Canvas Settings",
                            tint = StudioTextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        // 2. Interactive OBS Viewport (16:9 or 9:16 canvas with live overlay layers)
        item {
            ObsCanvasViewport(
                canvasConfig = canvasConfig,
                activeScene = activeObsScene,
                selectedSource = selectedObsSource,
                isLive = streamStatus == StreamStatus.LIVE,
                isScreenCaptureActive = isScreenCaptureActive,
                cameraSelector = cameraSelector,
                hasCameraPermission = hasCameraPermission,
                onRequestScreenCapture = {
                    val mediaProjectionManager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    screenCaptureLauncher.launch(mediaProjectionManager.createScreenCaptureIntent())
                },
                onSelectSource = { viewModel.selectObsSource(it) },
                onUpdateSourceTransform = { id, x, y, w, h ->
                    viewModel.updateObsSourceTransform(id, x, y, w, h)
                }
            )
        }

        // 3. Quick Tools Toolbar: Camera flip, screen cast, snapshot, floating bubble
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LazyRow(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    // Quick Screen Cast Toggle
                    item {
                        val isCasting = screenCastStatus == ScreenCastStatus.CASTING
                        OutlinedButton(
                            onClick = {
                                if (isCasting) {
                                    viewModel.stopScreenCast()
                                } else {
                                    viewModel.startScreenCast()
                                }
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = if (isCasting) StudioCyanAccent else StudioTextSecondary
                            ),
                            border = BorderStroke(
                                1.dp,
                                if (isCasting) StudioCyanAccent else StudioSurfaceBorder
                            ),
                            modifier = Modifier.testTag("studio_cast_button")
                        ) {
                            Icon(
                                imageVector = if (isCasting) Icons.Default.CastConnected else Icons.Default.Cast,
                                contentDescription = "Screen Cast",
                                tint = if (isCasting) StudioCyanAccent else StudioTextSecondary,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isCasting) "Casting" else "Cast",
                                fontSize = 11.sp,
                                fontWeight = if (isCasting) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }

                    // Snapshot Screenshot Button
                    item {
                        OutlinedButton(
                            onClick = { viewModel.takeScreenshot() },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = StudioTextSecondary),
                            border = BorderStroke(1.dp, StudioSurfaceBorder),
                            modifier = Modifier.testTag("studio_screenshot_btn")
                        ) {
                            Icon(imageVector = Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "Snapshot", fontSize = 11.sp)
                        }
                    }

                    // Floating Bubble Toggle Button
                    item {
                        OutlinedButton(
                            onClick = { viewModel.toggleFloatingBubble() },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = if (isFloatingBubbleActive) StudioPurplePrimary else StudioTextSecondary
                            ),
                            border = BorderStroke(
                                1.dp,
                                if (isFloatingBubbleActive) StudioPurplePrimary else StudioSurfaceBorder
                            ),
                            modifier = Modifier.testTag("studio_floating_bubble_btn")
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(if (isFloatingBubbleActive) StudioCyanAccent else StudioTextMuted)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = if (isFloatingBubbleActive) "Bubble ON" else "Bubble",
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Camera Lens Flip
                IconButton(
                    onClick = { viewModel.toggleCameraLens() },
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(StudioSurfaceElevated)
                        .border(1.dp, StudioSurfaceBorder, CircleShape)
                        .testTag("studio_flip_camera")
                ) {
                    Icon(
                        imageVector = Icons.Default.Cameraswitch,
                        contentDescription = "Switch Camera",
                        tint = StudioCyanAccent,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // 4. OBS Studio Dock Panels (Scenes, Sources, Audio Mixer)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("obs_studio_dock_card"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
                border = BorderStroke(1.dp, StudioSurfaceBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    // Tab Selector: Scenes, Sources, Audio Mixer
                    TabRow(
                        selectedTabIndex = activeDockTabIndex,
                        containerColor = Color.Transparent,
                        contentColor = StudioPurplePrimary,
                        divider = {},
                        indicator = { tabPositions ->
                            TabRowDefaults.SecondaryIndicator(
                                Modifier.tabIndicatorOffset(tabPositions[activeDockTabIndex]),
                                color = StudioCyanAccent,
                                height = 2.dp
                            )
                        }
                    ) {
                        Tab(
                            selected = activeDockTabIndex == 0,
                            onClick = { activeDockTabIndex = 0 },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Layers, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Scenes", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            },
                            selectedContentColor = StudioCyanAccent,
                            unselectedContentColor = StudioTextMuted
                        )
                        Tab(
                            selected = activeDockTabIndex == 1,
                            onClick = { activeDockTabIndex = 1 },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Widgets, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Sources", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            },
                            selectedContentColor = StudioCyanAccent,
                            unselectedContentColor = StudioTextMuted
                        )
                        Tab(
                            selected = activeDockTabIndex == 2,
                            onClick = { activeDockTabIndex = 2 },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.GraphicEq, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Mixer", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            },
                            selectedContentColor = StudioCyanAccent,
                            unselectedContentColor = StudioTextMuted
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    when (activeDockTabIndex) {
                        0 -> {
                            ObsScenesPanel(
                                scenes = obsScenes,
                                activeScene = activeObsScene,
                                onSelectScene = { viewModel.selectObsScene(it) },
                                onCreateScene = { viewModel.createCustomObsScene(it) },
                                onDuplicateScene = { viewModel.duplicateObsScene() },
                                onDeleteScene = { viewModel.deleteObsScene(it) },
                                onRenameScene = { id, name -> viewModel.renameObsScene(id, name) }
                            )
                        }
                        1 -> {
                            ObsSourcesPanel(
                                activeScene = activeObsScene,
                                selectedSource = selectedObsSource,
                                onSelectSource = { viewModel.selectObsSource(it) },
                                onToggleVisibility = { viewModel.toggleObsSourceVisibility(it) },
                                onToggleLock = { viewModel.toggleObsSourceLock(it) },
                                onRemoveSource = { viewModel.removeObsSource(it) },
                                onAddSource = { type, name -> viewModel.addObsSource(type, name) },
                                onBringForward = { viewModel.bringObsSourceForward(it) },
                                onSendBackward = { viewModel.sendObsSourceBackward(it) },
                                onUpdateSourceProperties = { id, txt, op, shape ->
                                    viewModel.updateObsSourceProperties(id, txt, op, shape)
                                }
                            )
                        }
                        2 -> {
                            ObsAudioMixerPanel(
                                mixerState = dualMixerState,
                                micMeter = dualMicMeter,
                                internalMeter = dualInternalMeter,
                                onSetMicVolume = { viewModel.setMicMixerVolume(it) },
                                onToggleMicMute = { viewModel.toggleMixerMicMute() },
                                onSetInternalVolume = { viewModel.setInternalMixerVolume(it) },
                                onToggleInternalMute = { viewModel.toggleMixerInternalMute() },
                                onToggleNoiseSuppression = { viewModel.toggleNoiseSuppression() },
                                onToggleAec = { viewModel.toggleAec() },
                                onSetAudioDelayMs = { viewModel.setAudioDelayMs(it) },
                                onToggleBluetoothSco = { viewModel.toggleBluetoothSco() }
                            )
                        }
                    }
                }
            }
        }

        // 5. Studio Master Control Dock: Go Live, Record, Pause/Resume
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("studio_master_control_dock"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
                border = BorderStroke(1.dp, StudioSurfaceBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "MASTER BROADCAST CONTROLS",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = StudioTextMuted,
                            letterSpacing = 1.sp
                        )
                        if (streamStatus == StreamStatus.LIVE) {
                            Text(
                                text = "ON AIR • ${telemetry.formattedDuration}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                color = StudioLiveRed
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Go Live Button
                        Button(
                            onClick = { viewModel.toggleStreaming() },
                            modifier = Modifier
                                .weight(1.3f)
                                .height(46.dp)
                                .testTag("studio_go_live_btn"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (streamStatus == StreamStatus.LIVE) StudioLiveRed else StudioPurplePrimary
                            )
                        ) {
                            Icon(
                                imageVector = if (streamStatus == StreamStatus.LIVE) Icons.Default.Stop else Icons.Default.Radio,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (streamStatus == StreamStatus.LIVE) "END STREAM" else "GO LIVE",
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp
                            )
                        }

                        // Record Button
                        OutlinedButton(
                            onClick = { viewModel.toggleRecording() },
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("studio_record_btn"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (recordingStatus == RecordingStatus.RECORDING) StudioRecordAmber.copy(0.2f) else Color.Transparent
                            ),
                            border = BorderStroke(
                                1.dp,
                                if (recordingStatus == RecordingStatus.RECORDING) StudioRecordAmber else StudioSurfaceBorder
                            )
                        ) {
                            Icon(
                                imageVector = if (recordingStatus == RecordingStatus.RECORDING) Icons.Default.Stop else Icons.Default.FiberManualRecord,
                                contentDescription = null,
                                tint = if (recordingStatus == RecordingStatus.RECORDING) StudioRecordAmber else StudioTextPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (recordingStatus == RecordingStatus.RECORDING) "STOP" else "REC",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = if (recordingStatus == RecordingStatus.RECORDING) StudioRecordAmber else StudioTextPrimary
                            )
                        }

                        // Pause / Resume Recording toggle
                        if (recordingStatus == RecordingStatus.RECORDING || recordingStatus == RecordingStatus.PAUSED) {
                            IconButton(
                                onClick = {
                                    if (recordingStatus == RecordingStatus.RECORDING) {
                                        viewModel.pauseRecording()
                                    } else {
                                        viewModel.resumeRecording()
                                    }
                                },
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(StudioSurface)
                                    .border(1.dp, StudioSurfaceBorder, RoundedCornerShape(10.dp))
                                    .testTag("studio_pause_record_btn")
                            ) {
                                Icon(
                                    imageVector = if (recordingStatus == RecordingStatus.RECORDING) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = "Pause/Resume Recording",
                                    tint = StudioRecordAmber
                                )
                            }
                        }

                        // Mic Mute Quick Toggle
                        IconButton(
                            onClick = { viewModel.toggleMixerMicMute() },
                            modifier = Modifier
                                .size(46.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(StudioSurface)
                                .border(1.dp, StudioSurfaceBorder, RoundedCornerShape(10.dp))
                        ) {
                            Icon(
                                imageVector = if (dualMixerState.isMicMuted) Icons.Default.MicOff else Icons.Default.Mic,
                                contentDescription = "Mute",
                                tint = if (dualMixerState.isMicMuted) StudioLiveRed else StudioAudioGreen
                            )
                        }
                    }
                }
            }
        }
    }

    // Canvas Settings & Orientation Dialog
    if (showCanvasSettingsDialog) {
        ObsCanvasSettingsDialog(
            canvasConfig = canvasConfig,
            onDismiss = { showCanvasSettingsDialog = false },
            onSetOrientation = { viewModel.setCanvasOrientation(it) },
            onSetPreset = { viewModel.setCanvasPreset(it) },
            onSetScaleMode = { viewModel.setScaleMode(it) },
            onSetBackgroundType = { viewModel.setBackgroundType(it) },
            onToggleSafeZones = { viewModel.toggleSafeZones() }
        )
    }
}
