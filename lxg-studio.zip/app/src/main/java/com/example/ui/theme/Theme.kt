package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LXGStudioColorScheme = darkColorScheme(
    primary = StudioPurplePrimary,
    onPrimary = Color.White,
    primaryContainer = StudioPurpleSecondary,
    onPrimaryContainer = Color.White,
    secondary = StudioCyanAccent,
    onSecondary = Color.Black,
    secondaryContainer = StudioSurfaceElevated,
    onSecondaryContainer = StudioCyanAccent,
    tertiary = StudioBlueAccent,
    onTertiary = Color.White,
    background = StudioDarkBg,
    onBackground = StudioTextPrimary,
    surface = StudioSurface,
    onSurface = StudioTextPrimary,
    surfaceVariant = StudioSurfaceElevated,
    onSurfaceVariant = StudioTextSecondary,
    outline = StudioSurfaceBorder,
    error = StudioLiveRed,
    onError = Color.White
)

@Composable
fun LXGStudioTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LXGStudioColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    LXGStudioTheme(content = content)
}
