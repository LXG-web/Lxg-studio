package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.RtmpDestinationEntity
import kotlinx.coroutines.flow.Flow

/**
 * Room Data Access Object (DAO) for RTMP destinations and secure credentials.
 */
@Dao
interface RtmpDestinationDao {

    @Query("SELECT * FROM rtmp_destinations ORDER BY created_at DESC")
    fun getAllDestinations(): Flow<List<RtmpDestinationEntity>>

    @Query("SELECT * FROM rtmp_destinations WHERE is_enabled = 1 ORDER BY created_at DESC")
    fun getEnabledDestinationsFlow(): Flow<List<RtmpDestinationEntity>>

    @Query("SELECT * FROM rtmp_destinations WHERE is_enabled = 1")
    suspend fun getEnabledDestinations(): List<RtmpDestinationEntity>

    @Query("SELECT * FROM rtmp_destinations WHERE id = :id LIMIT 1")
    suspend fun getDestinationById(id: Long): RtmpDestinationEntity?

    @Query("SELECT * FROM rtmp_destinations WHERE server_url = :url LIMIT 1")
    suspend fun getDestinationByUrl(url: String): RtmpDestinationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(destination: RtmpDestinationEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(destinations: List<RtmpDestinationEntity>): List<Long>

    @Update
    suspend fun update(destination: RtmpDestinationEntity)

    @Delete
    suspend fun delete(destination: RtmpDestinationEntity)

    @Query("DELETE FROM rtmp_destinations WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("UPDATE rtmp_destinations SET is_enabled = :isEnabled WHERE id = :id")
    suspend fun updateEnabled(id: Long, isEnabled: Boolean)

    @Query("UPDATE rtmp_destinations SET last_ping_ms = :pingMs WHERE id = :id")
    suspend fun updatePing(id: Long, pingMs: Long)

    @Query("DELETE FROM rtmp_destinations")
    suspend fun deleteAll()
}
