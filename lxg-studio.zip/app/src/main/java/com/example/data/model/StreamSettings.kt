package com.example.data.model

import android.media.MediaCodecList

data class StreamSettings(
    val resolutionWidth: Int = 1920,
    val resolutionHeight: Int = 1080,
    val resolutionLabel: String = "1080p Full HD",
    val fps: Int = 60,
    val videoBitrateKbps: Int = 4500, // 4.5 Mbps
    val audioBitrateKbps: Int = 160,
    val audioSampleRate: Int = 48000,
    val videoEncoder: String = "video/avc", // H.264 / AVC
    val videoOrientation: VideoOrientation = VideoOrientation.PORTRAIT,
    val micGainPercent: Int = 85,
    val isMicMuted: Boolean = false,
    val isInternalAudioEnabled: Boolean = true,
    val isReplayBufferEnabled: Boolean = true,
    val replayBufferDurationSec: Int = 30,
    val isFloatingBubbleEnabled: Boolean = true
) {
    val formattedBitrate: String
        get() = "${videoBitrateKbps} kbps"

    val formattedBitrateMbps: String
        get() = String.format(java.util.Locale.US, "%.1f Mbps", videoBitrateKbps / 1000f)

    companion object {
        val RESOLUTION_OPTIONS = listOf(
            ResolutionOption("720p HD", 1280, 720, 2500),
            ResolutionOption("1080p Full HD", 1920, 1080, 4500),
            ResolutionOption("1440p 2K", 2560, 1440, 8000),
            ResolutionOption("4K Ultra HD", 3840, 2160, 14000)
        )

        val FPS_OPTIONS = listOf(30, 60)

        // Bitrate adjustments: 2, 4, 6, 8, 10, 12, 16 Mbps
        val BITRATE_ADJUSTMENT_OPTIONS = listOf(
            2000,
            4000,
            6000,
            8000,
            10000,
            12000,
            16000
        )

        val BITRATE_PRESETS = listOf(
            BitratePreset("Eco (2 Mbps)", 2000),
            BitratePreset("Standard (4 Mbps)", 4000),
            BitratePreset("High Quality (6 Mbps)", 6000),
            BitratePreset("Pro Stream (8 Mbps)", 8000),
            BitratePreset("Ultra (12 Mbps)", 12000),
            BitratePreset("Master (16 Mbps)", 16000)
        )
    }
}

data class ResolutionOption(
    val label: String,
    val width: Int,
    val height: Int,
    val defaultBitrateKbps: Int
)

data class BitratePreset(
    val label: String,
    val kbps: Int
)

enum class VideoOrientation(val label: String) {
    PORTRAIT("Portrait (9:16)"),
    LANDSCAPE("Landscape (16:9)"),
    AUTO("Auto-Rotate")
}

data class HardwareEncoderInfo(
    val name: String,
    val mimeType: String,
    val isHardwareAccelerated: Boolean
)

data class CastDestination(
    val id: String,
    val name: String,
    val protocol: String, // "LAN Mirror (HTTP)", "Wi-Fi Display (Miracast)", "RTSP Server"
    val endpointUrl: String,
    val isConnected: Boolean = false,
    val latencyMs: Int = 24
)
